import React from 'react';
import { View, Text, StyleSheet, Dimensions } from 'react-native';
import { THEME } from '@/constants/Theme';

// Dummy data for chart visualization
const chartData = [
  { month: 'Jan', profit: 1200, expense: 800 },
  { month: 'Feb', profit: 1500, expense: 950 },
  { month: 'Mar', profit: 1100, expense: 750 },
  { month: 'Apr', profit: 1800, expense: 1200 },
  { month: 'May', profit: 1600, expense: 1100 },
  { month: 'Jun', profit: 2000, expense: 1300 },
];

export default function ProfitLossChart({ timeRange = 'month' }: { timeRange?: string }) {
  // Calculate max value for scaling
  const maxValue = Math.max(...chartData.map(item => Math.max(item.profit, item.expense)));
  
  // Get screen width for responsive chart
  const screenWidth = Dimensions.get('window').width;
  const chartWidth = screenWidth - 64; // Padding and margins
  const barWidth = chartWidth / chartData.length / 2.5; // Account for two bars per month
  
  return (
    <View style={styles.container}>
      <View style={styles.chartArea}>
        {/* Y-Axis labels */}
        <View style={styles.yAxis}>
          <Text style={styles.axisLabel}>${maxValue}</Text>
          <Text style={styles.axisLabel}>${maxValue / 2}</Text>
          <Text style={styles.axisLabel}>$0</Text>
        </View>
        
        {/* Chart bars */}
        <View style={styles.barsContainer}>
          {chartData.map((item, index) => (
            <View key={index} style={styles.monthGroup}>
              {/* Profit bar */}
              <View style={styles.barGroup}>
                <View 
                  style={[
                    styles.bar, 
                    styles.profitBar,
                    { 
                      height: (item.profit / maxValue) * 150,
                      width: barWidth,
                    }
                  ]} 
                />
              </View>
              
              {/* Expense bar */}
              <View style={styles.barGroup}>
                <View 
                  style={[
                    styles.bar, 
                    styles.expenseBar,
                    { 
                      height: (item.expense / maxValue) * 150,
                      width: barWidth,
                    }
                  ]} 
                />
              </View>
              
              {/* X-Axis label */}
              <Text style={styles.monthLabel}>{item.month}</Text>
            </View>
          ))}
        </View>
      </View>
      
      {/* Legend */}
      <View style={styles.legend}>
        <View style={styles.legendItem}>
          <View style={[styles.legendColor, styles.profitLegend]} />
          <Text style={styles.legendText}>Revenue</Text>
        </View>
        <View style={styles.legendItem}>
          <View style={[styles.legendColor, styles.expenseLegend]} />
          <Text style={styles.legendText}>Expenses</Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  chartArea: {
    flexDirection: 'row',
    height: 180,
    marginBottom: 20,
  },
  yAxis: {
    width: 40,
    height: 150,
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    paddingRight: 8,
  },
  axisLabel: {
    fontFamily: 'Poppins-Regular',
    fontSize: 10,
    color: THEME.colors.textLight,
  },
  barsContainer: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'flex-end',
    height: 150,
  },
  monthGroup: {
    alignItems: 'center',
    justifyContent: 'flex-end',
    height: 150,
    flexDirection: 'row',
  },
  barGroup: {
    alignItems: 'center',
    justifyContent: 'flex-end',
    height: 150,
  },
  bar: {
    borderTopLeftRadius: 4,
    borderTopRightRadius: 4,
    marginHorizontal: 2,
  },
  profitBar: {
    backgroundColor: THEME.colors.primary,
  },
  expenseBar: {
    backgroundColor: THEME.colors.secondary,
  },
  monthLabel: {
    position: 'absolute',
    bottom: -20,
    fontFamily: 'Poppins-Regular',
    fontSize: 10,
    color: THEME.colors.textLight,
    textAlign: 'center',
    width: 40,
  },
  legend: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 4,
  },
  legendItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginHorizontal: 12,
  },
  legendColor: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: 6,
  },
  profitLegend: {
    backgroundColor: THEME.colors.primary,
  },
  expenseLegend: {
    backgroundColor: THEME.colors.secondary,
  },
  legendText: {
    fontFamily: 'Poppins-Regular',
    fontSize: 12,
    color: THEME.colors.text,
  },
});