import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { THEME } from '@/constants/Theme';

// Dummy data for pie chart
const expenseData = [
  { category: 'Fuel', percentage: 45, color: '#1E88E5' },
  { category: 'Driver Payments', percentage: 30, color: '#F57C00' },
  { category: 'Tolls', percentage: 15, color: '#43A047' },
  { category: 'Maintenance', percentage: 10, color: '#E53935' },
];

export default function ExpensePieChart() {
  let cumulativeAngle = 0;
  
  return (
    <View style={styles.container}>
      <View style={styles.chartContainer}>
        <View style={styles.pieContainer}>
          {expenseData.map((item, index) => {
            const startAngle = cumulativeAngle;
            const angle = (item.percentage / 100) * 360;
            cumulativeAngle += angle;
            
            return (
              <View
                key={index}
                style={[
                  styles.pieSlice,
                  {
                    backgroundColor: item.color,
                    transform: [
                      { rotate: `${startAngle}deg` },
                      { translateX: 70 },
                      { rotate: `-${startAngle}deg` },
                      { translateX: -70 },
                    ],
                    width: 70,
                    height: 70,
                    borderTopRightRadius: angle >= 180 ? 0 : 70,
                    borderBottomRightRadius: angle >= 180 ? 0 : 70,
                    zIndex: 100 - index,
                  },
                ]}
              />
            );
          })}
          <View style={styles.centerCircle} />
        </View>
      </View>
      
      <View style={styles.legend}>
        {expenseData.map((item, index) => (
          <View key={index} style={styles.legendItem}>
            <View style={[styles.legendColor, { backgroundColor: item.color }]} />
            <Text style={styles.legendCategory}>{item.category}</Text>
            <Text style={styles.legendPercentage}>{item.percentage}%</Text>
          </View>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingVertical: 8,
  },
  chartContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    height: 160,
  },
  pieContainer: {
    width: 140,
    height: 140,
    borderRadius: 70,
    overflow: 'hidden',
    position: 'relative',
    backgroundColor: '#f0f0f0',
  },
  pieSlice: {
    position: 'absolute',
    width: 70,
    height: 140,
    left: 70,
    top: 0,
    backgroundColor: 'transparent',
    transformOrigin: 'left center',
  },
  centerCircle: {
    position: 'absolute',
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: THEME.colors.white,
    top: '50%',
    left: '50%',
    transform: [{ translateX: -30 }, { translateY: -30 }],
    zIndex: 101,
  },
  legend: {
    marginTop: 20,
  },
  legendItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  legendColor: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: 8,
  },
  legendCategory: {
    fontFamily: 'Poppins-Medium',
    fontSize: 14,
    color: THEME.colors.text,
    flex: 1,
  },
  legendPercentage: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 14,
    color: THEME.colors.text,
    width: 40,
    textAlign: 'right',
  },
});