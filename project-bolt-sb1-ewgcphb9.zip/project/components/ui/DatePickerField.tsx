import React, { ReactNode } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Platform } from 'react-native';
import { THEME } from '@/constants/Theme';
import { format } from '@/utils/dateUtils';

interface DatePickerFieldProps {
  label: string;
  value: Date;
  onChange: (date: Date) => void;
  icon?: ReactNode;
}

export default function DatePickerField({ 
  label, 
  value, 
  onChange,
  icon
}: DatePickerFieldProps) {
  const handlePress = () => {
    // In a real app, this would show a date picker
    // For demo purposes, we'll just advance the date by one day
    const newDate = new Date(value);
    newDate.setDate(newDate.getDate() + 1);
    onChange(newDate);
  };
  
  return (
    <TouchableOpacity 
      style={styles.container}
      onPress={handlePress}
    >
      {icon && <View style={styles.iconContainer}>{icon}</View>}
      <View style={styles.content}>
        <Text style={styles.label}>{label}</Text>
        <Text style={styles.value}>{format(value)}</Text>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: THEME.colors.border,
    borderRadius: 8,
    marginBottom: 16,
    height: 56,
    paddingHorizontal: 12,
  },
  iconContainer: {
    marginRight: 12,
  },
  content: {
    flex: 1,
  },
  label: {
    fontFamily: 'Poppins-Regular',
    fontSize: 12,
    color: THEME.colors.textLight,
  },
  value: {
    fontFamily: 'Poppins-Medium',
    fontSize: 16,
    color: THEME.colors.text,
  },
});