import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { THEME } from '@/constants/Theme';
import { Truck, Users, FileText, ChartBar as BarChart2 } from 'lucide-react-native';

interface EmptyStateProps {
  title: string;
  message: string;
  icon: 'truck' | 'users' | 'file-text' | 'bar-chart';
}

export default function EmptyState({ title, message, icon }: EmptyStateProps) {
  const renderIcon = () => {
    switch (icon) {
      case 'truck':
        return <Truck size={64} color={THEME.colors.primary} />;
      case 'users':
        return <Users size={64} color={THEME.colors.primary} />;
      case 'file-text':
        return <FileText size={64} color={THEME.colors.primary} />;
      case 'bar-chart':
        return <BarChart2 size={64} color={THEME.colors.primary} />;
      default:
        return <FileText size={64} color={THEME.colors.primary} />;
    }
  };
  
  return (
    <View style={styles.container}>
      <View style={styles.iconContainer}>
        {renderIcon()}
      </View>
      <Text style={styles.title}>{title}</Text>
      <Text style={styles.message}>{message}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  iconContainer: {
    marginBottom: 24,
    opacity: 0.7,
  },
  title: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 20,
    color: THEME.colors.text,
    marginBottom: 8,
    textAlign: 'center',
  },
  message: {
    fontFamily: 'Poppins-Regular',
    fontSize: 16,
    color: THEME.colors.textLight,
    textAlign: 'center',
    maxWidth: 250,
  }
});