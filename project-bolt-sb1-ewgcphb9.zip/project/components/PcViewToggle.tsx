import React, { useState } from 'react';
import { TouchableOpacity, Text, StyleSheet, Platform } from 'react-native';
import { THEME } from '@/constants/Theme';
import { Monitor, Smartphone } from 'lucide-react-native';

export default function PcViewToggle() {
  const [isPcView, setIsPcView] = useState(false);
  
  // Simplified toggle - in a real app this would update the UI layout
  const toggleView = () => {
    setIsPcView(!isPcView);
    // Would trigger a layout change in a real app
  };
  
  if (Platform.OS !== 'web') {
    // Only show on web
    return null;
  }
  
  return (
    <TouchableOpacity 
      style={styles.container}
      onPress={toggleView}
    >
      {isPcView ? (
        <>
          <Smartphone size={16} color={THEME.colors.white} style={styles.icon} />
          <Text style={styles.text}>Mobile View</Text>
        </>
      ) : (
        <>
          <Monitor size={16} color={THEME.colors.white} style={styles.icon} />
          <Text style={styles.text}>PC View</Text>
        </>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 16,
    marginRight: 16,
  },
  icon: {
    marginRight: 6,
  },
  text: {
    fontFamily: 'Poppins-Medium',
    fontSize: 12,
    color: THEME.colors.white,
  }
});