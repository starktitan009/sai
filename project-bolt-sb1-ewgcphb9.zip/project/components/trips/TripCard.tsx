import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { THEME } from '@/constants/Theme';
import { Trip } from '@/types/Trip';
import { format } from '@/utils/dateUtils';
import { calculateTripProfit } from '@/utils/calculations';
import { MapPin, Calendar, DollarSign } from 'lucide-react-native';
import TripStatusBadge from './TripStatusBadge';

interface TripCardProps {
  trip: Trip;
  onPress: () => void;
}

export default function TripCard({ trip, onPress }: TripCardProps) {
  const profit = calculateTripProfit(trip);
  const isProfitable = profit > 0;
  
  return (
    <TouchableOpacity style={styles.container} onPress={onPress}>
      <View style={styles.header}>
        <Text style={styles.truckNumber}>{trip.truckNumber}</Text>
        <TripStatusBadge status={trip.status} />
      </View>
      
      <View style={styles.routeContainer}>
        <MapPin size={16} color={THEME.colors.primary} style={styles.icon} />
        <Text style={styles.routeText}>{trip.from} → {trip.to}</Text>
      </View>
      
      <View style={styles.infoRow}>
        <View style={styles.infoItem}>
          <Calendar size={16} color={THEME.colors.textLight} style={styles.icon} />
          <Text style={styles.infoText}>{format(new Date(trip.startDate))}</Text>
        </View>
        
        <View style={styles.infoItem}>
          <DollarSign size={16} color={isProfitable ? THEME.colors.success : THEME.colors.danger} style={styles.icon} />
          <Text 
            style={[
              styles.profitText, 
              isProfitable ? styles.profitPositive : styles.profitNegative
            ]}
          >
            ${Math.abs(profit).toFixed(0)}
          </Text>
        </View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: THEME.colors.white,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    ...THEME.shadowProps,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  truckNumber: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 18,
    color: THEME.colors.text,
  },
  routeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  routeText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 16,
    color: THEME.colors.text,
  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  infoItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  icon: {
    marginRight: 6,
  },
  infoText: {
    fontFamily: 'Poppins-Regular',
    fontSize: 14,
    color: THEME.colors.textLight,
  },
  profitText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 14,
  },
  profitPositive: {
    color: THEME.colors.success,
  },
  profitNegative: {
    color: THEME.colors.danger,
  },
});