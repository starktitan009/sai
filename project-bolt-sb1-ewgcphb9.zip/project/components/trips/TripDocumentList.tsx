import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { THEME } from '@/constants/Theme';
import { TripDocument } from '@/types/Trip';
import { Upload, File, Eye } from 'lucide-react-native';

interface TripDocumentListProps {
  documents: TripDocument[];
}

export default function TripDocumentList({ documents }: TripDocumentListProps) {
  if (documents.length === 0) {
    return (
      <View style={styles.emptyContainer}>
        <Text style={styles.emptyText}>No documents uploaded</Text>
        <TouchableOpacity style={styles.addButton}>
          <Upload size={16} color={THEME.colors.white} />
          <Text style={styles.addButtonText}>Upload Document</Text>
        </TouchableOpacity>
      </View>
    );
  }
  
  return (
    <View style={styles.container}>
      {documents.map((document, index) => (
        <View key={index} style={styles.documentItem}>
          <View style={styles.documentIcon}>
            {document.thumbnailUrl ? (
              <Image 
                source={{ uri: document.thumbnailUrl }} 
                style={styles.thumbnail} 
              />
            ) : (
              <File size={24} color={THEME.colors.primary} />
            )}
          </View>
          
          <View style={styles.documentDetails}>
            <Text style={styles.documentTitle}>{document.title}</Text>
            <Text style={styles.documentMeta}>
              {document.fileType} • {document.fileSize}
            </Text>
          </View>
          
          <TouchableOpacity style={styles.viewButton}>
            <Eye size={20} color={THEME.colors.primary} />
          </TouchableOpacity>
        </View>
      ))}
      
      <TouchableOpacity style={styles.addDocumentButton}>
        <Upload size={16} color={THEME.colors.primary} />
        <Text style={styles.addDocumentText}>Add Document</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 16,
  },
  documentItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  documentIcon: {
    width: 48,
    height: 48,
    borderRadius: 8,
    backgroundColor: 'rgba(30, 136, 229, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  thumbnail: {
    width: 48,
    height: 48,
    borderRadius: 8,
  },
  documentDetails: {
    flex: 1,
  },
  documentTitle: {
    fontFamily: 'Poppins-Medium',
    fontSize: 16,
    color: THEME.colors.text,
  },
  documentMeta: {
    fontFamily: 'Poppins-Regular',
    fontSize: 12,
    color: THEME.colors.textLight,
  },
  viewButton: {
    padding: 8,
  },
  addDocumentButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: THEME.colors.primary,
    borderRadius: 8,
    paddingVertical: 10,
    backgroundColor: 'rgba(30, 136, 229, 0.05)',
    marginTop: 8,
  },
  addDocumentText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 14,
    color: THEME.colors.primary,
    marginLeft: 8,
  },
  emptyContainer: {
    padding: 24,
    alignItems: 'center',
  },
  emptyText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 16,
    color: THEME.colors.textLight,
    marginBottom: 16,
  },
  addButton: {
    backgroundColor: THEME.colors.primary,
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 8,
  },
  addButtonText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 14,
    color: THEME.colors.white,
    marginLeft: 8,
  },
});