import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { THEME } from '@/constants/Theme';

interface TripStatusBadgeProps {
  status: 'ongoing' | 'completed' | 'cancelled';
  small?: boolean;
}

export default function TripStatusBadge({ status, small }: TripStatusBadgeProps) {
  let backgroundColor = '';
  let textColor = '';
  
  switch (status) {
    case 'ongoing':
      backgroundColor = 'rgba(33, 150, 243, 0.1)';
      textColor = THEME.colors.primary;
      break;
    case 'completed':
      backgroundColor = 'rgba(76, 175, 80, 0.1)';
      textColor = THEME.colors.success;
      break;
    case 'cancelled':
      backgroundColor = 'rgba(244, 67, 54, 0.1)';
      textColor = THEME.colors.danger;
      break;
    default:
      backgroundColor = 'rgba(158, 158, 158, 0.1)';
      textColor = THEME.colors.textLight;
  }
  
  return (
    <View style={[
      styles.badge, 
      { backgroundColor },
      small ? styles.smallBadge : {}
    ]}>
      <Text style={[
        styles.badgeText, 
        { color: textColor },
        small ? styles.smallBadgeText : {}
      ]}>
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  badge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },
  badgeText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 14,
    textTransform: 'capitalize',
  },
  smallBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
  },
  smallBadgeText: {
    fontSize: 12,
  }
});