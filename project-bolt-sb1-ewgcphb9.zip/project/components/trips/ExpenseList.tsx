import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { THEME } from '@/constants/Theme';
import { TripExpense } from '@/types/Trip';
import { Plus } from 'lucide-react-native';

interface ExpenseListProps {
  expenses: TripExpense[];
}

export default function ExpenseList({ expenses }: ExpenseListProps) {
  if (expenses.length === 0) {
    return (
      <View style={styles.emptyContainer}>
        <Text style={styles.emptyText}>No expenses recorded yet</Text>
        <TouchableOpacity style={styles.addButton}>
          <Plus size={16} color={THEME.colors.white} />
          <Text style={styles.addButtonText}>Add Expense</Text>
        </TouchableOpacity>
      </View>
    );
  }
  
  const totalExpenses = expenses.reduce((sum, expense) => sum + expense.amount, 0);
  
  return (
    <View style={styles.container}>
      {expenses.map((expense, index) => (
        <View key={index} style={styles.expenseItem}>
          <View style={styles.expenseType}>
            <Text style={styles.expenseLabel}>{formatExpenseType(expense.type)}</Text>
            {expense.notes && <Text style={styles.expenseNotes}>{expense.notes}</Text>}
          </View>
          <Text style={styles.expenseAmount}>${expense.amount.toFixed(2)}</Text>
        </View>
      ))}
      
      <View style={styles.totalRow}>
        <Text style={styles.totalLabel}>Total Expenses</Text>
        <Text style={styles.totalAmount}>${totalExpenses.toFixed(2)}</Text>
      </View>
      
      <TouchableOpacity style={styles.addExpenseButton}>
        <Plus size={16} color={THEME.colors.primary} />
        <Text style={styles.addExpenseText}>Add Expense</Text>
      </TouchableOpacity>
    </View>
  );
}

function formatExpenseType(type: string): string {
  switch (type) {
    case 'fuel':
      return 'Fuel';
    case 'driver':
      return 'Driver Payment';
    case 'coDriver':
      return 'Co-Driver Payment';
    case 'toll':
      return 'Toll Tax';
    case 'advance':
      return 'Advance';
    case 'maintenance':
      return 'Maintenance';
    case 'other':
      return 'Other Expenses';
    default:
      return type.charAt(0).toUpperCase() + type.slice(1);
  }
}

const styles = StyleSheet.create({
  container: {
    padding: 16,
  },
  expenseItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  expenseType: {
    flex: 1,
  },
  expenseLabel: {
    fontFamily: 'Poppins-Medium',
    fontSize: 16,
    color: THEME.colors.text,
  },
  expenseNotes: {
    fontFamily: 'Poppins-Regular',
    fontSize: 12,
    color: THEME.colors.textLight,
  },
  expenseAmount: {
    fontFamily: 'Poppins-Medium',
    fontSize: 16,
    color: THEME.colors.text,
    minWidth: 80,
    textAlign: 'right',
  },
  totalRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: THEME.colors.backgroundLight,
    marginTop: 8,
    marginBottom: 16,
  },
  totalLabel: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 16,
    color: THEME.colors.text,
  },
  totalAmount: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 16,
    color: THEME.colors.text,
    minWidth: 80,
    textAlign: 'right',
  },
  addExpenseButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: THEME.colors.primary,
    borderRadius: 8,
    paddingVertical: 10,
    backgroundColor: 'rgba(30, 136, 229, 0.05)',
  },
  addExpenseText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 14,
    color: THEME.colors.primary,
    marginLeft: 8,
  },
  emptyContainer: {
    padding: 24,
    alignItems: 'center',
  },
  emptyText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 16,
    color: THEME.colors.textLight,
    marginBottom: 16,
  },
  addButton: {
    backgroundColor: THEME.colors.primary,
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 8,
  },
  addButtonText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 14,
    color: THEME.colors.white,
    marginLeft: 8,
  },
});