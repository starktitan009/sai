import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { THEME } from '@/constants/Theme';
import { Driver } from '@/types/Driver';
import { Phone, Calendar, User, MoveVertical as MoreVertical } from 'lucide-react-native';
import { format } from '@/utils/dateUtils';

interface DriverCardProps {
  driver: Driver;
}

export default function DriverCard({ driver }: DriverCardProps) {
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View style={styles.profileSection}>
          {driver.photo ? (
            <Image source={{ uri: driver.photo }} style={styles.profileImage} />
          ) : (
            <View style={styles.profilePlaceholder}>
              <User size={24} color={THEME.colors.primary} />
            </View>
          )}
          
          <View style={styles.nameContainer}>
            <Text style={styles.name}>{driver.name}</Text>
            <View style={styles.statusBadge}>
              <Text style={styles.statusText}>{driver.status}</Text>
            </View>
          </View>
        </View>
        
        <TouchableOpacity style={styles.menuButton}>
          <MoreVertical size={20} color={THEME.colors.text} />
        </TouchableOpacity>
      </View>
      
      <View style={styles.infoContainer}>
        <View style={styles.infoItem}>
          <Phone size={16} color={THEME.colors.textLight} style={styles.infoIcon} />
          <Text style={styles.infoText}>{driver.phone}</Text>
        </View>
        
        <View style={styles.infoItem}>
          <Calendar size={16} color={THEME.colors.textLight} style={styles.infoIcon} />
          <Text style={styles.infoText}>
            Joined {format(new Date(driver.joinDate))}
          </Text>
        </View>
      </View>
      
      <View style={styles.footer}>
        <View style={styles.tripCounter}>
          <Text style={styles.tripCount}>{driver.trips.length}</Text>
          <Text style={styles.tripLabel}>Trips</Text>
        </View>
        
        <TouchableOpacity style={styles.viewButton}>
          <Text style={styles.viewButtonText}>View Details</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: THEME.colors.white,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    ...THEME.shadowProps,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  profileSection: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  profileImage: {
    width: 48,
    height: 48,
    borderRadius: 24,
    marginRight: 12,
  },
  profilePlaceholder: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(30, 136, 229, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  nameContainer: {
    flexDirection: 'column',
  },
  name: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 16,
    color: THEME.colors.text,
    marginBottom: 4,
  },
  statusBadge: {
    backgroundColor: 'rgba(76, 175, 80, 0.1)',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 12,
    alignSelf: 'flex-start',
  },
  statusText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 12,
    color: THEME.colors.success,
    textTransform: 'capitalize',
  },
  menuButton: {
    padding: 4,
  },
  infoContainer: {
    marginBottom: 16,
  },
  infoItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  infoIcon: {
    marginRight: 8,
  },
  infoText: {
    fontFamily: 'Poppins-Regular',
    fontSize: 14,
    color: THEME.colors.text,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderTopWidth: 1,
    borderTopColor: THEME.colors.backgroundLight,
    paddingTop: 16,
  },
  tripCounter: {
    flexDirection: 'row',
    alignItems: 'baseline',
  },
  tripCount: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 18,
    color: THEME.colors.primary,
  },
  tripLabel: {
    fontFamily: 'Poppins-Medium',
    fontSize: 14,
    color: THEME.colors.textLight,
    marginLeft: 4,
  },
  viewButton: {
    backgroundColor: 'rgba(30, 136, 229, 0.1)',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 8,
  },
  viewButtonText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 14,
    color: THEME.colors.primary,
  },
});