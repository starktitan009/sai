import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { THEME } from '@/constants/Theme';
import { Truck, DollarSign, Calendar } from 'lucide-react-native';
import { useTrips } from '@/hooks/useTrips';
import { calculateTripSummary } from '@/utils/calculations';

export default function DashboardSummary() {
  const { trips } = useTrips();
  const summary = calculateTripSummary(trips);
  
  // Count active trips
  const activeTrips = trips.filter(trip => trip.status === 'ongoing').length;
  
  // Calculate upcoming trips (future start date)
  const today = new Date();
  const upcomingTrips = trips.filter(trip => new Date(trip.startDate) > today).length;
  
  return (
    <View style={styles.container}>
      <View style={styles.card}>
        <View style={styles.cardIcon}>
          <Truck size={24} color={THEME.colors.primary} />
        </View>
        <Text style={styles.cardValue}>{activeTrips}</Text>
        <Text style={styles.cardLabel}>Active Trips</Text>
      </View>
      
      <View style={styles.card}>
        <View style={styles.cardIcon}>
          <DollarSign size={24} color={THEME.colors.primary} />
        </View>
        <Text style={styles.cardValue}>${summary.profit.toFixed(0)}</Text>
        <Text style={styles.cardLabel}>Monthly Profit</Text>
      </View>
      
      <View style={styles.card}>
        <View style={styles.cardIcon}>
          <Calendar size={24} color={THEME.colors.primary} />
        </View>
        <Text style={styles.cardValue}>{upcomingTrips}</Text>
        <Text style={styles.cardLabel}>Upcoming</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 24,
  },
  card: {
    backgroundColor: THEME.colors.white,
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    justifyContent: 'center',
    width: '31%',
    ...THEME.shadowProps,
  },
  cardIcon: {
    backgroundColor: 'rgba(30, 136, 229, 0.1)',
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  cardValue: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 18,
    color: THEME.colors.text,
    marginBottom: 4,
  },
  cardLabel: {
    fontFamily: 'Poppins-Regular',
    fontSize: 12,
    color: THEME.colors.textLight,
    textAlign: 'center',
  }
});