import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList } from 'react-native';
import { THEME } from '@/constants/Theme';
import { PenTool as Tool, Bell, Calendar } from 'lucide-react-native';
import { useMaintenanceItems } from '@/hooks/useMaintenanceItems';
import { MaintenanceItem } from '@/types/Maintenance';
import { format } from '@/utils/dateUtils';

export default function UpcomingMaintenanceCard() {
  const { maintenanceItems } = useMaintenanceItems();
  
  // Sort by date and get upcoming items
  const today = new Date();
  const upcomingItems = maintenanceItems
    .filter(item => new Date(item.scheduledDate) > today)
    .sort((a, b) => new Date(a.scheduledDate).getTime() - new Date(b.scheduledDate).getTime())
    .slice(0, 3);
  
  if (upcomingItems.length === 0) {
    return (
      <View style={styles.emptyContainer}>
        <Text style={styles.emptyText}>No maintenance scheduled</Text>
        <TouchableOpacity style={styles.addButton}>
          <Text style={styles.addButtonText}>Schedule maintenance</Text>
        </TouchableOpacity>
      </View>
    );
  }
  
  const renderItem = ({ item }: { item: MaintenanceItem }) => (
    <View style={styles.maintenanceItem}>
      <View style={styles.iconContainer}>
        <Tool size={20} color={THEME.colors.primary} />
      </View>
      
      <View style={styles.itemDetails}>
        <Text style={styles.itemTitle}>{item.title}</Text>
        <Text style={styles.itemDate}>
          <Calendar size={12} color={THEME.colors.textLight} style={styles.inlineIcon} /> 
          {format(new Date(item.scheduledDate))}
        </Text>
      </View>
      
      <TouchableOpacity style={styles.reminderButton}>
        <Bell size={16} color={THEME.colors.white} />
      </TouchableOpacity>
    </View>
  );
  
  return (
    <View style={styles.container}>
      <FlatList
        data={upcomingItems}
        renderItem={renderItem}
        keyExtractor={item => item.id}
        scrollEnabled={false}
        ItemSeparatorComponent={() => <View style={styles.separator} />}
      />
      
      <TouchableOpacity style={styles.viewAllButton}>
        <Text style={styles.viewAllText}>Schedule New Maintenance</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: THEME.colors.white,
    borderRadius: 12,
    ...THEME.shadowProps,
  },
  maintenanceItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
  },
  iconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(30, 136, 229, 0.1)',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  itemDetails: {
    flex: 1,
  },
  itemTitle: {
    fontFamily: 'Poppins-Medium',
    fontSize: 16,
    color: THEME.colors.text,
    marginBottom: 4,
  },
  itemDate: {
    fontFamily: 'Poppins-Regular',
    fontSize: 14,
    color: THEME.colors.textLight,
    flexDirection: 'row',
    alignItems: 'center',
  },
  inlineIcon: {
    marginRight: 4,
  },
  reminderButton: {
    backgroundColor: THEME.colors.primary,
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
  },
  separator: {
    height: 1,
    backgroundColor: THEME.colors.backgroundLight,
    marginHorizontal: 16,
  },
  viewAllButton: {
    borderTopWidth: 1,
    borderTopColor: THEME.colors.backgroundLight,
    padding: 16,
    alignItems: 'center',
  },
  viewAllText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 14,
    color: THEME.colors.primary,
  },
  emptyContainer: {
    backgroundColor: THEME.colors.white,
    borderRadius: 12,
    padding: 24,
    alignItems: 'center',
    ...THEME.shadowProps,
  },
  emptyText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 16,
    color: THEME.colors.textLight,
    marginBottom: 16,
  },
  addButton: {
    backgroundColor: THEME.colors.primary,
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 8,
  },
  addButtonText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 14,
    color: THEME.colors.white,
  },
});