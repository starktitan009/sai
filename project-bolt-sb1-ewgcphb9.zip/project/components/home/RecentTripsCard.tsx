import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList } from 'react-native';
import { THEME } from '@/constants/Theme';
import { useTrips } from '@/hooks/useTrips';
import { Trip } from '@/types/Trip';
import { router } from 'expo-router';
import { ChevronRight } from 'lucide-react-native';
import { format } from '@/utils/dateUtils';
import TripStatusBadge from '@/components/trips/TripStatusBadge';

export default function RecentTripsCard() {
  const { trips } = useTrips();
  
  // Sort trips by date, newest first, and take at most 3
  const recentTrips = [...trips]
    .sort((a, b) => new Date(b.startDate).getTime() - new Date(a.startDate).getTime())
    .slice(0, 3);
  
  if (recentTrips.length === 0) {
    return (
      <View style={styles.emptyContainer}>
        <Text style={styles.emptyText}>No trips recorded yet</Text>
        <TouchableOpacity 
          style={styles.addButton}
          onPress={() => router.push('/trip/new')}
        >
          <Text style={styles.addButtonText}>Add your first trip</Text>
        </TouchableOpacity>
      </View>
    );
  }
  
  const renderItem = ({ item }: { item: Trip }) => (
    <TouchableOpacity 
      style={styles.tripItem}
      onPress={() => router.push(`/trip/details/${item.id}`)}
    >
      <View style={styles.tripDetails}>
        <Text style={styles.tripRoute}>{item.from} → {item.to}</Text>
        <Text style={styles.tripDate}>{format(new Date(item.startDate))}</Text>
      </View>
      
      <View style={styles.rightSection}>
        <TripStatusBadge status={item.status} small />
        <ChevronRight size={20} color={THEME.colors.textLight} />
      </View>
    </TouchableOpacity>
  );
  
  return (
    <View style={styles.container}>
      <FlatList
        data={recentTrips}
        renderItem={renderItem}
        keyExtractor={item => item.id}
        scrollEnabled={false}
        ItemSeparatorComponent={() => <View style={styles.separator} />}
      />
      
      <TouchableOpacity 
        style={styles.viewAllButton}
        onPress={() => router.push('/trips')}
      >
        <Text style={styles.viewAllText}>View All Trips</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: THEME.colors.white,
    borderRadius: 12,
    ...THEME.shadowProps,
  },
  tripItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
  },
  tripDetails: {
    flex: 1,
  },
  tripRoute: {
    fontFamily: 'Poppins-Medium',
    fontSize: 16,
    color: THEME.colors.text,
    marginBottom: 4,
  },
  tripDate: {
    fontFamily: 'Poppins-Regular',
    fontSize: 14,
    color: THEME.colors.textLight,
  },
  rightSection: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  separator: {
    height: 1,
    backgroundColor: THEME.colors.backgroundLight,
    marginHorizontal: 16,
  },
  viewAllButton: {
    borderTopWidth: 1,
    borderTopColor: THEME.colors.backgroundLight,
    padding: 16,
    alignItems: 'center',
  },
  viewAllText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 14,
    color: THEME.colors.primary,
  },
  emptyContainer: {
    backgroundColor: THEME.colors.white,
    borderRadius: 12,
    padding: 24,
    alignItems: 'center',
    ...THEME.shadowProps,
  },
  emptyText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 16,
    color: THEME.colors.textLight,
    marginBottom: 16,
  },
  addButton: {
    backgroundColor: THEME.colors.primary,
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 8,
  },
  addButtonText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 14,
    color: THEME.colors.white,
  },
});