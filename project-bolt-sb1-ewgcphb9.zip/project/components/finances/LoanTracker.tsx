import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { THEME } from '@/constants/Theme';

// Dummy loan data for the demo
const loans = [
  {
    id: '1',
    name: 'Truck Purchase Loan',
    totalAmount: 50000,
    paidAmount: 32500,
    remainingPayments: 8,
    nextPaymentDate: new Date(2025, 6, 15).toISOString(),
    interestRate: 7.5,
  }
];

export default function LoanTracker() {
  // Empty state
  if (loans.length === 0) {
    return (
      <View style={styles.emptyContainer}>
        <Text style={styles.emptyText}>No active loans</Text>
        <TouchableOpacity style={styles.addButton}>
          <Text style={styles.addButtonText}>Add Loan Details</Text>
        </TouchableOpacity>
      </View>
    );
  }
  
  return (
    <View style={styles.container}>
      {loans.map(loan => {
        const progressPercentage = (loan.paidAmount / loan.totalAmount) * 100;
        const remainingAmount = loan.totalAmount - loan.paidAmount;
        
        return (
          <View key={loan.id} style={styles.loanCard}>
            <View style={styles.loanHeader}>
              <Text style={styles.loanName}>{loan.name}</Text>
              <Text style={styles.interestRate}>{loan.interestRate}% APR</Text>
            </View>
            
            <View style={styles.progressSection}>
              <View style={styles.progressBar}>
                <View 
                  style={[
                    styles.progressFill,
                    { width: `${progressPercentage}%` }
                  ]} 
                />
              </View>
              <Text style={styles.progressText}>{progressPercentage.toFixed(0)}% paid</Text>
            </View>
            
            <View style={styles.detailsContainer}>
              <View style={styles.detailColumn}>
                <Text style={styles.detailLabel}>Total Loan</Text>
                <Text style={styles.detailValue}>${loan.totalAmount}</Text>
              </View>
              
              <View style={styles.detailColumn}>
                <Text style={styles.detailLabel}>Paid Amount</Text>
                <Text style={styles.detailValue}>${loan.paidAmount}</Text>
              </View>
              
              <View style={styles.detailColumn}>
                <Text style={styles.detailLabel}>Remaining</Text>
                <Text style={styles.detailValue}>${remainingAmount}</Text>
              </View>
            </View>
            
            <View style={styles.paymentInfo}>
              <Text style={styles.paymentText}>
                {loan.remainingPayments} payments remaining
              </Text>
              <TouchableOpacity style={styles.recordButton}>
                <Text style={styles.recordButtonText}>Record Payment</Text>
              </TouchableOpacity>
            </View>
          </View>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    borderRadius: 12,
  },
  loanCard: {
    backgroundColor: THEME.colors.white,
    borderRadius: 12,
    padding: 16,
    ...THEME.shadowProps,
  },
  loanHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  loanName: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 18,
    color: THEME.colors.text,
  },
  interestRate: {
    fontFamily: 'Poppins-Medium',
    fontSize: 14,
    color: THEME.colors.secondary,
    backgroundColor: 'rgba(245, 124, 0, 0.1)',
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: 4,
  },
  progressSection: {
    marginBottom: 16,
  },
  progressBar: {
    height: 8,
    backgroundColor: THEME.colors.backgroundLight,
    borderRadius: 4,
    marginBottom: 4,
  },
  progressFill: {
    height: 8,
    backgroundColor: THEME.colors.primary,
    borderRadius: 4,
  },
  progressText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 12,
    color: THEME.colors.textLight,
    textAlign: 'right',
  },
  detailsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  detailColumn: {
    alignItems: 'center',
  },
  detailLabel: {
    fontFamily: 'Poppins-Regular',
    fontSize: 12,
    color: THEME.colors.textLight,
    marginBottom: 4,
  },
  detailValue: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 16,
    color: THEME.colors.text,
  },
  paymentInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderTopWidth: 1,
    borderTopColor: THEME.colors.backgroundLight,
    paddingTop: 16,
  },
  paymentText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 14,
    color: THEME.colors.textLight,
  },
  recordButton: {
    backgroundColor: THEME.colors.primary,
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 6,
  },
  recordButtonText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 12,
    color: THEME.colors.white,
  },
  emptyContainer: {
    backgroundColor: THEME.colors.white,
    borderRadius: 12,
    padding: 24,
    alignItems: 'center',
    ...THEME.shadowProps,
  },
  emptyText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 16,
    color: THEME.colors.textLight,
    marginBottom: 16,
  },
  addButton: {
    backgroundColor: THEME.colors.primary,
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 8,
  },
  addButtonText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 14,
    color: THEME.colors.white,
  },
});