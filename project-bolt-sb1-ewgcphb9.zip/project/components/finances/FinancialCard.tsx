import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { THEME } from '@/constants/Theme';
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign 
} from 'lucide-react-native';

interface FinancialCardProps {
  title: string;
  amount: number;
  growth: string;
  positive: boolean;
  icon: 'trending-up' | 'trending-down' | 'dollar-sign';
}

export default function FinancialCard({ 
  title,
  amount,
  growth,
  positive,
  icon
}: FinancialCardProps) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>{title}</Text>
      <Text style={styles.amount}>${amount.toFixed(0)}</Text>
      <View style={styles.growthContainer}>
        {icon === 'trending-up' && (
          <TrendingUp 
            size={16} 
            color={positive ? THEME.colors.success : THEME.colors.danger} 
            style={styles.growthIcon}
          />
        )}
        {icon === 'trending-down' && (
          <TrendingDown 
            size={16} 
            color={positive ? THEME.colors.success : THEME.colors.danger} 
            style={styles.growthIcon}
          />
        )}
        {icon === 'dollar-sign' && (
          <DollarSign 
            size={16} 
            color={positive ? THEME.colors.success : THEME.colors.danger} 
            style={styles.growthIcon}
          />
        )}
        <Text 
          style={[
            styles.growthText, 
            positive ? styles.positiveGrowth : styles.negativeGrowth
          ]}
        >
          {growth}
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: THEME.colors.white,
    borderRadius: 12,
    padding: 12,
    ...THEME.shadowProps,
    width: '31%',
  },
  title: {
    fontFamily: 'Poppins-Regular',
    fontSize: 12,
    color: THEME.colors.textLight,
    marginBottom: 4,
  },
  amount: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 16,
    color: THEME.colors.text,
    marginBottom: 8,
  },
  growthContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  growthIcon: {
    marginRight: 4,
  },
  growthText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 12,
  },
  positiveGrowth: {
    color: THEME.colors.success,
  },
  negativeGrowth: {
    color: THEME.colors.danger,
  },
});