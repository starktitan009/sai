import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { THEME } from '@/constants/Theme';
import { Document } from '@/types/Document';
import { Calendar, FileText, Download, Eye } from 'lucide-react-native';
import { format } from '@/utils/dateUtils';

interface DocumentCardProps {
  document: Document;
}

export default function DocumentCard({ document }: DocumentCardProps) {
  return (
    <View style={styles.container}>
      <View style={styles.documentHeader}>
        <View style={styles.iconContainer}>
          {document.thumbnailUrl ? (
            <Image source={{ uri: document.thumbnailUrl }} style={styles.thumbnail} />
          ) : (
            <FileText size={24} color={THEME.colors.primary} />
          )}
        </View>
        
        <View style={styles.titleContainer}>
          <Text style={styles.title}>{document.title}</Text>
          <Text style={styles.fileName}>{document.fileName}</Text>
        </View>
      </View>
      
      <View style={styles.infoRow}>
        <View style={styles.infoItem}>
          <Calendar size={14} color={THEME.colors.textLight} style={styles.infoIcon} />
          <Text style={styles.infoText}>
            Uploaded: {format(new Date(document.uploadDate))}
          </Text>
        </View>
        
        {document.expiryDate && (
          <View style={styles.infoItem}>
            <Calendar size={14} color={THEME.colors.textLight} style={styles.infoIcon} />
            <Text style={styles.infoText}>
              Expires: {format(new Date(document.expiryDate))}
            </Text>
          </View>
        )}
      </View>
      
      <View style={styles.footer}>
        <Text style={styles.fileSize}>{document.fileSize}</Text>
        
        <View style={styles.actions}>
          <TouchableOpacity style={styles.actionButton}>
            <Eye size={20} color={THEME.colors.primary} />
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.actionButton}>
            <Download size={20} color={THEME.colors.primary} />
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: THEME.colors.white,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    ...THEME.shadowProps,
  },
  documentHeader: {
    flexDirection: 'row',
    marginBottom: 12,
  },
  iconContainer: {
    width: 48,
    height: 48,
    borderRadius: 8,
    backgroundColor: 'rgba(30, 136, 229, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  thumbnail: {
    width: 48,
    height: 48,
    borderRadius: 8,
  },
  titleContainer: {
    flex: 1,
  },
  title: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 16,
    color: THEME.colors.text,
    marginBottom: 4,
  },
  fileName: {
    fontFamily: 'Poppins-Regular',
    fontSize: 14,
    color: THEME.colors.textLight,
  },
  infoRow: {
    marginBottom: 12,
  },
  infoItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
  },
  infoIcon: {
    marginRight: 8,
  },
  infoText: {
    fontFamily: 'Poppins-Regular',
    fontSize: 12,
    color: THEME.colors.textLight,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderTopWidth: 1,
    borderTopColor: THEME.colors.backgroundLight,
    paddingTop: 12,
  },
  fileSize: {
    fontFamily: 'Poppins-Medium',
    fontSize: 14,
    color: THEME.colors.textLight,
  },
  actions: {
    flexDirection: 'row',
  },
  actionButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(30, 136, 229, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 8,
  },
});