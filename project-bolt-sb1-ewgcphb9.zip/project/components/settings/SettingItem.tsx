import React, { ReactNode } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { THEME } from '@/constants/Theme';
import { ChevronRight } from 'lucide-react-native';

interface SettingItemProps {
  icon: ReactNode;
  title: string;
  description: string;
  control?: ReactNode;
  isButton?: boolean;
  onPress?: () => void;
  danger?: boolean;
}

export default function SettingItem({ 
  icon, 
  title, 
  description, 
  control, 
  isButton = false,
  onPress,
  danger = false
}: SettingItemProps) {
  const Wrapper = isButton ? TouchableOpacity : View;
  
  return (
    <Wrapper 
      style={styles.container} 
      onPress={isButton ? onPress : undefined}
    >
      <View style={styles.iconContainer}>
        {icon}
      </View>
      
      <View style={styles.contentContainer}>
        <Text style={[styles.title, danger && styles.dangerTitle]}>{title}</Text>
        <Text style={styles.description}>{description}</Text>
      </View>
      
      {control ? (
        <View style={styles.controlContainer}>
          {control}
        </View>
      ) : isButton ? (
        <ChevronRight size={20} color={THEME.colors.textLight} />
      ) : null}
    </Wrapper>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
  },
  iconContainer: {
    marginRight: 16,
  },
  contentContainer: {
    flex: 1,
  },
  title: {
    fontFamily: 'Poppins-Medium',
    fontSize: 16,
    color: THEME.colors.text,
    marginBottom: 4,
  },
  dangerTitle: {
    color: THEME.colors.danger,
  },
  description: {
    fontFamily: 'Poppins-Regular',
    fontSize: 14,
    color: THEME.colors.textLight,
  },
  controlContainer: {
    marginLeft: 8,
  },
});