import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { THEME } from '@/constants/Theme';
import { X, FileText, FileSpreadsheet, Calendar, Check } from 'lucide-react-native';
import { router } from 'expo-router';
import { useTrips } from '@/hooks/useTrips';
import DatePickerField from '@/components/ui/DatePickerField';

export default function ExportTripsScreen() {
  const { trips } = useTrips();
  const [exportFormat, setExportFormat] = useState<'pdf' | 'excel'>('pdf');
  const [startDate, setStartDate] = useState(new Date(Date.now() - 30 * 86400000)); // 30 days ago
  const [endDate, setEndDate] = useState(new Date());
  const [includeExpenses, setIncludeExpenses] = useState(true);
  const [includeDocuments, setIncludeDocuments] = useState(true);
  
  const handleExport = () => {
    // In a real app, this would generate and download the file
    alert(`Exported ${trips.length} trips to ${exportFormat.toUpperCase()}`);
    router.back();
  };
  
  return (
    <SafeAreaView style={styles.container} edges={['top', 'right', 'left']}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Export Trips</Text>
        <TouchableOpacity style={styles.closeButton} onPress={() => router.back()}>
          <X size={24} color={THEME.colors.text} />
        </TouchableOpacity>
      </View>
      
      <ScrollView style={styles.scrollView} contentContainerStyle={styles.contentContainer}>
        <Text style={styles.sectionTitle}>Export Format</Text>
        <View style={styles.formatSelector}>
          <TouchableOpacity 
            style={[styles.formatButton, exportFormat === 'pdf' && styles.selectedFormat]}
            onPress={() => setExportFormat('pdf')}
          >
            <FileText size={24} color={exportFormat === 'pdf' ? THEME.colors.white : THEME.colors.primary} />
            <Text style={[styles.formatText, exportFormat === 'pdf' && styles.selectedFormatText]}>
              PDF Document
            </Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={[styles.formatButton, exportFormat === 'excel' && styles.selectedFormat]}
            onPress={() => setExportFormat('excel')}
          >
            <FileSpreadsheet size={24} color={exportFormat === 'excel' ? THEME.colors.white : THEME.colors.primary} />
            <Text style={[styles.formatText, exportFormat === 'excel' && styles.selectedFormatText]}>
              Excel Spreadsheet
            </Text>
          </TouchableOpacity>
        </View>
        
        <Text style={styles.sectionTitle}>Date Range</Text>
        <View style={styles.dateSection}>
          <DatePickerField
            label="Start Date"
            value={startDate}
            onChange={setStartDate}
            icon={<Calendar size={20} color={THEME.colors.primary} />}
          />
          
          <DatePickerField
            label="End Date"
            value={endDate}
            onChange={setEndDate}
            icon={<Calendar size={20} color={THEME.colors.primary} />}
          />
        </View>
        
        <Text style={styles.sectionTitle}>Include in Export</Text>
        <View style={styles.optionsCard}>
          <TouchableOpacity 
            style={styles.optionRow}
            onPress={() => setIncludeExpenses(!includeExpenses)}
          >
            <View style={[styles.checkbox, includeExpenses && styles.checkedBox]}>
              {includeExpenses && <Check size={16} color={THEME.colors.white} />}
            </View>
            <Text style={styles.optionText}>Detailed Expenses</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.optionRow}
            onPress={() => setIncludeDocuments(!includeDocuments)}
          >
            <View style={[styles.checkbox, includeDocuments && styles.checkedBox]}>
              {includeDocuments && <Check size={16} color={THEME.colors.white} />}
            </View>
            <Text style={styles.optionText}>Document References</Text>
          </TouchableOpacity>
        </View>
        
        <View style={styles.summaryCard}>
          <Text style={styles.summaryTitle}>Export Summary</Text>
          <Text style={styles.summaryText}>
            {trips.length} trips will be exported as {exportFormat.toUpperCase()}
          </Text>
        </View>
        
        <TouchableOpacity style={styles.exportButton} onPress={handleExport}>
          <Text style={styles.exportButtonText}>Generate & Download</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: THEME.colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
    backgroundColor: THEME.colors.white,
    ...THEME.shadowProps,
  },
  headerTitle: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 20,
    color: THEME.colors.text,
  },
  closeButton: {
    padding: 8,
  },
  scrollView: {
    flex: 1,
  },
  contentContainer: {
    padding: 16,
    paddingBottom: 32,
  },
  sectionTitle: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 18,
    color: THEME.colors.text,
    marginBottom: 12,
    marginTop: 16,
  },
  formatSelector: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  formatButton: {
    flex: 1,
    backgroundColor: 'rgba(30, 136, 229, 0.1)',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
    borderRadius: 12,
    marginHorizontal: 6,
  },
  selectedFormat: {
    backgroundColor: THEME.colors.primary,
  },
  formatText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 16,
    color: THEME.colors.primary,
    marginTop: 12,
    textAlign: 'center',
  },
  selectedFormatText: {
    color: THEME.colors.white,
  },
  dateSection: {
    backgroundColor: THEME.colors.white,
    borderRadius: 12,
    padding: 16,
    ...THEME.shadowProps,
  },
  optionsCard: {
    backgroundColor: THEME.colors.white,
    borderRadius: 12,
    padding: 16,
    ...THEME.shadowProps,
  },
  optionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  checkbox: {
    width: 24,
    height: 24,
    borderWidth: 2,
    borderColor: THEME.colors.primary,
    borderRadius: 6,
    marginRight: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  checkedBox: {
    backgroundColor: THEME.colors.primary,
  },
  optionText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 16,
    color: THEME.colors.text,
  },
  summaryCard: {
    backgroundColor: THEME.colors.white,
    borderRadius: 12,
    padding: 16,
    marginTop: 24,
    marginBottom: 24,
    ...THEME.shadowProps,
  },
  summaryTitle: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 18,
    color: THEME.colors.text,
    marginBottom: 8,
  },
  summaryText: {
    fontFamily: 'Poppins-Regular',
    fontSize: 16,
    color: THEME.colors.text,
  },
  exportButton: {
    backgroundColor: THEME.colors.secondary,
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  exportButtonText: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 16,
    color: THEME.colors.white,
  }
});