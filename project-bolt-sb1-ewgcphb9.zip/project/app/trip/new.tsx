import React, { useState } from 'react';
import { View, Text, StyleSheet, TextInput, ScrollView, TouchableOpacity, KeyboardAvoidingView, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { THEME } from '@/constants/Theme';
import { X, Calendar, Upload, MapPin, DollarSign, User, Truck } from 'lucide-react-native';
import { router } from 'expo-router';
import { useTrips } from '@/hooks/useTrips';
import DatePickerField from '@/components/ui/DatePickerField';
import { Trip, TripExpense } from '@/types/Trip';

export default function NewTripScreen() {
  const { addTrip } = useTrips();
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [startDate, setStartDate] = useState(new Date());
  const [endDate, setEndDate] = useState(new Date(Date.now() + 86400000 * 2)); // 2 days later
  const [truckNumber, setTruckNumber] = useState('');
  const [revenue, setRevenue] = useState('');
  const [driverName, setDriverName] = useState('');
  const [coDriverName, setCoDriverName] = useState('');
  
  // Expenses
  const [fuel, setFuel] = useState('');
  const [driverPayment, setDriverPayment] = useState('');
  const [coDriverPayment, setCoDriverPayment] = useState('');
  const [tollTax, setTollTax] = useState('');
  const [advance, setAdvance] = useState('');
  const [otherExpenses, setOtherExpenses] = useState('');
  
  const handleCreate = () => {
    if (!from || !to || !truckNumber || !revenue) {
      alert('Please fill all required fields');
      return;
    }
    
    const expenses: TripExpense[] = [
      { type: 'fuel', amount: parseFloat(fuel) || 0, notes: 'Fuel expenses' },
      { type: 'driver', amount: parseFloat(driverPayment) || 0, notes: 'Driver payment' },
      { type: 'coDriver', amount: parseFloat(coDriverPayment) || 0, notes: 'Co-driver payment' },
      { type: 'toll', amount: parseFloat(tollTax) || 0, notes: 'Toll taxes' },
      { type: 'advance', amount: parseFloat(advance) || 0, notes: 'Advance payment' },
      { type: 'other', amount: parseFloat(otherExpenses) || 0, notes: 'Miscellaneous expenses' }
    ];
    
    const newTrip: Trip = {
      id: Date.now().toString(),
      from,
      to,
      startDate: startDate.toISOString(),
      endDate: endDate.toISOString(),
      truckNumber,
      revenue: parseFloat(revenue),
      driverName,
      coDriverName,
      expenses,
      documents: [],
      status: 'ongoing',
      createdAt: new Date().toISOString()
    };
    
    addTrip(newTrip);
    router.back();
  };
  
  return (
    <KeyboardAvoidingView 
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={{ flex: 1 }}
    >
      <SafeAreaView style={styles.container} edges={['top', 'right', 'left']}>
        <View style={styles.header}>
          <Text style={styles.headerTitle}>New Trip</Text>
          <TouchableOpacity style={styles.closeButton} onPress={() => router.back()}>
            <X size={24} color={THEME.colors.text} />
          </TouchableOpacity>
        </View>
        
        <ScrollView style={styles.scrollView} contentContainerStyle={styles.formContainer}>
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Trip Details</Text>
            
            <View style={styles.inputContainer}>
              <MapPin size={20} color={THEME.colors.primary} style={styles.inputIcon} />
              <TextInput
                style={styles.input}
                placeholder="From Location"
                value={from}
                onChangeText={setFrom}
                placeholderTextColor={THEME.colors.textLight}
              />
            </View>
            
            <View style={styles.inputContainer}>
              <MapPin size={20} color={THEME.colors.primary} style={styles.inputIcon} />
              <TextInput
                style={styles.input}
                placeholder="To Location"
                value={to}
                onChangeText={setTo}
                placeholderTextColor={THEME.colors.textLight}
              />
            </View>
            
            <DatePickerField
              label="Start Date"
              value={startDate}
              onChange={setStartDate}
              icon={<Calendar size={20} color={THEME.colors.primary} />}
            />
            
            <DatePickerField
              label="End Date"
              value={endDate}
              onChange={setEndDate}
              icon={<Calendar size={20} color={THEME.colors.primary} />}
            />
            
            <View style={styles.inputContainer}>
              <Truck size={20} color={THEME.colors.primary} style={styles.inputIcon} />
              <TextInput
                style={styles.input}
                placeholder="Truck Number"
                value={truckNumber}
                onChangeText={setTruckNumber}
                placeholderTextColor={THEME.colors.textLight}
              />
            </View>
            
            <View style={styles.inputContainer}>
              <DollarSign size={20} color={THEME.colors.primary} style={styles.inputIcon} />
              <TextInput
                style={styles.input}
                placeholder="Revenue Amount"
                value={revenue}
                onChangeText={setRevenue}
                keyboardType="numeric"
                placeholderTextColor={THEME.colors.textLight}
              />
            </View>
          </View>
          
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Driver Information</Text>
            
            <View style={styles.inputContainer}>
              <User size={20} color={THEME.colors.primary} style={styles.inputIcon} />
              <TextInput
                style={styles.input}
                placeholder="Driver Name"
                value={driverName}
                onChangeText={setDriverName}
                placeholderTextColor={THEME.colors.textLight}
              />
            </View>
            
            <View style={styles.inputContainer}>
              <User size={20} color={THEME.colors.primary} style={styles.inputIcon} />
              <TextInput
                style={styles.input}
                placeholder="Co-Driver Name (optional)"
                value={coDriverName}
                onChangeText={setCoDriverName}
                placeholderTextColor={THEME.colors.textLight}
              />
            </View>
          </View>
          
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Expenses</Text>
            
            <View style={styles.inputContainer}>
              <DollarSign size={20} color={THEME.colors.primary} style={styles.inputIcon} />
              <TextInput
                style={styles.input}
                placeholder="Fuel Expenses"
                value={fuel}
                onChangeText={setFuel}
                keyboardType="numeric"
                placeholderTextColor={THEME.colors.textLight}
              />
            </View>
            
            <View style={styles.inputContainer}>
              <DollarSign size={20} color={THEME.colors.primary} style={styles.inputIcon} />
              <TextInput
                style={styles.input}
                placeholder="Driver Payment"
                value={driverPayment}
                onChangeText={setDriverPayment}
                keyboardType="numeric"
                placeholderTextColor={THEME.colors.textLight}
              />
            </View>
            
            <View style={styles.inputContainer}>
              <DollarSign size={20} color={THEME.colors.primary} style={styles.inputIcon} />
              <TextInput
                style={styles.input}
                placeholder="Co-Driver Payment"
                value={coDriverPayment}
                onChangeText={setCoDriverPayment}
                keyboardType="numeric"
                placeholderTextColor={THEME.colors.textLight}
              />
            </View>
            
            <View style={styles.inputContainer}>
              <DollarSign size={20} color={THEME.colors.primary} style={styles.inputIcon} />
              <TextInput
                style={styles.input}
                placeholder="Toll Tax"
                value={tollTax}
                onChangeText={setTollTax}
                keyboardType="numeric"
                placeholderTextColor={THEME.colors.textLight}
              />
            </View>
            
            <View style={styles.inputContainer}>
              <DollarSign size={20} color={THEME.colors.primary} style={styles.inputIcon} />
              <TextInput
                style={styles.input}
                placeholder="Advance Amount"
                value={advance}
                onChangeText={setAdvance}
                keyboardType="numeric"
                placeholderTextColor={THEME.colors.textLight}
              />
            </View>
            
            <View style={styles.inputContainer}>
              <DollarSign size={20} color={THEME.colors.primary} style={styles.inputIcon} />
              <TextInput
                style={styles.input}
                placeholder="Other Expenses"
                value={otherExpenses}
                onChangeText={setOtherExpenses}
                keyboardType="numeric"
                placeholderTextColor={THEME.colors.textLight}
              />
            </View>
            
            <View style={styles.documentSection}>
              <Text style={styles.documentTitle}>Add Documents</Text>
              <TouchableOpacity style={styles.documentButton}>
                <Upload size={20} color={THEME.colors.white} />
                <Text style={styles.documentButtonText}>Upload Receipts</Text>
              </TouchableOpacity>
            </View>
          </View>
          
          <View style={styles.buttonContainer}>
            <TouchableOpacity style={styles.cancelButton} onPress={() => router.back()}>
              <Text style={styles.cancelButtonText}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.createButton} onPress={handleCreate}>
              <Text style={styles.createButtonText}>Create Trip</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </SafeAreaView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: THEME.colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
    backgroundColor: THEME.colors.white,
    ...THEME.shadowProps,
  },
  headerTitle: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 20,
    color: THEME.colors.text,
  },
  closeButton: {
    padding: 8,
  },
  scrollView: {
    flex: 1,
  },
  formContainer: {
    padding: 16,
    paddingBottom: 32,
  },
  section: {
    marginBottom: 24,
    backgroundColor: THEME.colors.white,
    borderRadius: 12,
    padding: 16,
    ...THEME.shadowProps,
  },
  sectionTitle: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 18,
    color: THEME.colors.text,
    marginBottom: 16,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: THEME.colors.border,
    borderRadius: 8,
    marginBottom: 16,
    height: 48,
    paddingHorizontal: 12,
  },
  inputIcon: {
    marginRight: 12,
  },
  input: {
    flex: 1,
    height: 48,
    fontFamily: 'Poppins-Regular',
    color: THEME.colors.text,
  },
  documentSection: {
    marginTop: 16,
    alignItems: 'center',
  },
  documentTitle: {
    fontFamily: 'Poppins-Medium',
    fontSize: 16,
    color: THEME.colors.text,
    marginBottom: 12,
  },
  documentButton: {
    flexDirection: 'row',
    backgroundColor: THEME.colors.secondary,
    borderRadius: 8,
    paddingVertical: 12,
    paddingHorizontal: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  documentButtonText: {
    fontFamily: 'Poppins-Medium',
    color: THEME.colors.white,
    marginLeft: 8,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 16,
  },
  cancelButton: {
    flex: 1,
    borderWidth: 1,
    borderColor: THEME.colors.border,
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
    marginRight: 8,
  },
  createButton: {
    flex: 2,
    backgroundColor: THEME.colors.primary,
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
    marginLeft: 8,
  },
  cancelButtonText: {
    fontFamily: 'Poppins-Medium',
    color: THEME.colors.text,
  },
  createButtonText: {
    fontFamily: 'Poppins-Medium',
    color: THEME.colors.white,
  },
});