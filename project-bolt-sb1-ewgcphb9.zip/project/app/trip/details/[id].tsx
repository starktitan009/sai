import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useLocalSearchParams, router } from 'expo-router';
import { THEME } from '@/constants/Theme';
import { useTrips } from '@/hooks/useTrips';
import { format } from '@/utils/dateUtils';
import { Truck, MapPin, Calendar, DollarSign, Users, FileText, CircleAlert as AlertCircle, CreditCard as Edit, Trash } from 'lucide-react-native';
import ExpenseList from '@/components/trips/ExpenseList';
import TripDocumentList from '@/components/trips/TripDocumentList';
import TripStatusBadge from '@/components/trips/TripStatusBadge';

export default function TripDetailScreen() {
  const { id } = useLocalSearchParams();
  const { getTrip, removeTrip, updateTripStatus } = useTrips();
  const trip = getTrip(id as string);
  
  const [showExpenses, setShowExpenses] = useState(true);
  const [showDocuments, setShowDocuments] = useState(true);
  
  if (!trip) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.notFound}>
          <AlertCircle size={64} color={THEME.colors.danger} />
          <Text style={styles.notFoundText}>Trip not found</Text>
          <TouchableOpacity 
            style={styles.backButton} 
            onPress={() => router.back()}
          >
            <Text style={styles.backButtonText}>Go Back</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }
  
  const totalExpenses = trip.expenses.reduce((sum, expense) => sum + expense.amount, 0);
  const profit = trip.revenue - totalExpenses;
  
  const handleStatusChange = (newStatus: 'ongoing' | 'completed' | 'cancelled') => {
    updateTripStatus(trip.id, newStatus);
  };
  
  const handleDelete = () => {
    Alert.alert(
      'Delete Trip',
      'Are you sure you want to delete this trip? This action cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Delete', 
          onPress: () => {
            removeTrip(trip.id);
            router.back();
          },
          style: 'destructive' 
        }
      ]
    );
  };
  
  return (
    <SafeAreaView style={styles.container} edges={['right', 'left']}>
      <ScrollView style={styles.scrollView} contentContainerStyle={styles.contentContainer}>
        <View style={styles.header}>
          <View style={styles.titleContainer}>
            <Text style={styles.tripTitle}>{trip.from} to {trip.to}</Text>
            <TripStatusBadge status={trip.status} />
          </View>
          
          <View style={styles.actions}>
            <TouchableOpacity style={styles.editButton}>
              <Edit size={20} color={THEME.colors.primary} />
            </TouchableOpacity>
            <TouchableOpacity style={styles.deleteButton} onPress={handleDelete}>
              <Trash size={20} color={THEME.colors.danger} />
            </TouchableOpacity>
          </View>
        </View>
        
        <View style={styles.card}>
          <View style={styles.infoRow}>
            <View style={styles.infoIcon}>
              <Truck size={20} color={THEME.colors.primary} />
            </View>
            <View style={styles.infoContent}>
              <Text style={styles.infoLabel}>Truck Number</Text>
              <Text style={styles.infoValue}>{trip.truckNumber}</Text>
            </View>
          </View>
          
          <View style={styles.infoRow}>
            <View style={styles.infoIcon}>
              <MapPin size={20} color={THEME.colors.primary} />
            </View>
            <View style={styles.infoContent}>
              <Text style={styles.infoLabel}>Route</Text>
              <Text style={styles.infoValue}>{trip.from} → {trip.to}</Text>
            </View>
          </View>
          
          <View style={styles.infoRow}>
            <View style={styles.infoIcon}>
              <Calendar size={20} color={THEME.colors.primary} />
            </View>
            <View style={styles.infoContent}>
              <Text style={styles.infoLabel}>Trip Period</Text>
              <Text style={styles.infoValue}>
                {format(new Date(trip.startDate))} - {format(new Date(trip.endDate))}
              </Text>
            </View>
          </View>
          
          <View style={styles.infoRow}>
            <View style={styles.infoIcon}>
              <Users size={20} color={THEME.colors.primary} />
            </View>
            <View style={styles.infoContent}>
              <Text style={styles.infoLabel}>Drivers</Text>
              <Text style={styles.infoValue}>
                {trip.driverName}{trip.coDriverName ? ` & ${trip.coDriverName}` : ''}
              </Text>
            </View>
          </View>
        </View>
        
        <View style={styles.summaryCard}>
          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>Revenue</Text>
            <Text style={styles.summaryValue}>${trip.revenue.toFixed(2)}</Text>
          </View>
          
          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>Expenses</Text>
            <Text style={styles.summaryValue}>-${totalExpenses.toFixed(2)}</Text>
          </View>
          
          <View style={styles.divider} />
          
          <View style={styles.summaryRow}>
            <Text style={styles.profitLabel}>Profit</Text>
            <Text style={[styles.profitValue, profit < 0 && styles.lossValue]}>
              ${profit.toFixed(2)}
            </Text>
          </View>
        </View>
        
        <View style={styles.sectionContainer}>
          <TouchableOpacity 
            style={styles.sectionHeader}
            onPress={() => setShowExpenses(!showExpenses)}
          >
            <Text style={styles.sectionTitle}>Expenses</Text>
            <Text style={styles.sectionToggle}>{showExpenses ? 'Hide' : 'Show'}</Text>
          </TouchableOpacity>
          
          {showExpenses && <ExpenseList expenses={trip.expenses} />}
        </View>
        
        <View style={styles.sectionContainer}>
          <TouchableOpacity 
            style={styles.sectionHeader}
            onPress={() => setShowDocuments(!showDocuments)}
          >
            <Text style={styles.sectionTitle}>Documents</Text>
            <Text style={styles.sectionToggle}>{showDocuments ? 'Hide' : 'Show'}</Text>
          </TouchableOpacity>
          
          {showDocuments && <TripDocumentList documents={trip.documents} />}
        </View>
        
        <View style={styles.statusButtons}>
          <TouchableOpacity
            style={[
              styles.statusButton,
              trip.status === 'ongoing' && styles.activeStatusButton
            ]}
            onPress={() => handleStatusChange('ongoing')}
          >
            <Text style={[
              styles.statusButtonText,
              trip.status === 'ongoing' && styles.activeStatusButtonText
            ]}>Ongoing</Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[
              styles.statusButton,
              trip.status === 'completed' && styles.activeStatusButton
            ]}
            onPress={() => handleStatusChange('completed')}
          >
            <Text style={[
              styles.statusButtonText,
              trip.status === 'completed' && styles.activeStatusButtonText
            ]}>Completed</Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[
              styles.statusButton,
              trip.status === 'cancelled' && styles.cancelledStatusButton
            ]}
            onPress={() => handleStatusChange('cancelled')}
          >
            <Text style={[
              styles.statusButtonText,
              trip.status === 'cancelled' && styles.cancelledStatusButtonText
            ]}>Cancelled</Text>
          </TouchableOpacity>
        </View>
        
        <View style={styles.exportButtonContainer}>
          <TouchableOpacity style={styles.exportButton}>
            <FileText size={20} color={THEME.colors.white} />
            <Text style={styles.exportButtonText}>Export Trip Details</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: THEME.colors.background,
  },
  scrollView: {
    flex: 1,
  },
  contentContainer: {
    padding: 16,
    paddingBottom: 32,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  titleContainer: {
    flex: 1,
  },
  tripTitle: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 20,
    color: THEME.colors.text,
    marginBottom: 4,
  },
  actions: {
    flexDirection: 'row',
  },
  editButton: {
    backgroundColor: 'rgba(30, 136, 229, 0.1)',
    padding: 10,
    borderRadius: 8,
    marginRight: 8,
  },
  deleteButton: {
    backgroundColor: 'rgba(244, 67, 54, 0.1)',
    padding: 10,
    borderRadius: 8,
  },
  card: {
    backgroundColor: THEME.colors.white,
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    ...THEME.shadowProps,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  infoIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(30, 136, 229, 0.1)',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  infoContent: {
    flex: 1,
  },
  infoLabel: {
    fontFamily: 'Poppins-Regular',
    fontSize: 14,
    color: THEME.colors.textLight,
  },
  infoValue: {
    fontFamily: 'Poppins-Medium',
    fontSize: 16,
    color: THEME.colors.text,
  },
  summaryCard: {
    backgroundColor: THEME.colors.white,
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    ...THEME.shadowProps,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  summaryLabel: {
    fontFamily: 'Poppins-Medium',
    fontSize: 16,
    color: THEME.colors.text,
  },
  summaryValue: {
    fontFamily: 'Poppins-Medium',
    fontSize: 16,
    color: THEME.colors.text,
  },
  divider: {
    height: 1,
    backgroundColor: THEME.colors.backgroundLight,
    marginVertical: 12,
  },
  profitLabel: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 18,
    color: THEME.colors.text,
  },
  profitValue: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 18,
    color: THEME.colors.success,
  },
  lossValue: {
    color: THEME.colors.danger,
  },
  sectionContainer: {
    backgroundColor: THEME.colors.white,
    borderRadius: 12,
    marginBottom: 16,
    ...THEME.shadowProps,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: THEME.colors.backgroundLight,
  },
  sectionTitle: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 18,
    color: THEME.colors.text,
  },
  sectionToggle: {
    fontFamily: 'Poppins-Medium',
    fontSize: 14,
    color: THEME.colors.primary,
  },
  statusButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  statusButton: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: THEME.colors.border,
    marginHorizontal: 4,
  },
  activeStatusButton: {
    backgroundColor: THEME.colors.primary,
    borderColor: THEME.colors.primary,
  },
  cancelledStatusButton: {
    backgroundColor: THEME.colors.danger,
    borderColor: THEME.colors.danger,
  },
  statusButtonText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 14,
    color: THEME.colors.text,
  },
  activeStatusButtonText: {
    color: THEME.colors.white,
  },
  cancelledStatusButtonText: {
    color: THEME.colors.white,
  },
  exportButtonContainer: {
    marginTop: 8,
    marginBottom: 24,
  },
  exportButton: {
    backgroundColor: THEME.colors.secondary,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 16,
    borderRadius: 12,
  },
  exportButtonText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 16,
    color: THEME.colors.white,
    marginLeft: 8,
  },
  notFound: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  notFoundText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 18,
    color: THEME.colors.text,
    marginTop: 16,
    marginBottom: 24,
  },
  backButton: {
    backgroundColor: THEME.colors.primary,
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 8,
  },
  backButtonText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 16,
    color: THEME.colors.white,
  },
});