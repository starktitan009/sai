import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { THEME } from '@/constants/Theme';
import ProfitLossChart from '@/components/charts/ProfitLossChart';
import ExpensePieChart from '@/components/charts/ExpensePieChart';
import { useTrips } from '@/hooks/useTrips';
import { calculateTripSummary } from '@/utils/calculations';
import FinancialCard from '@/components/finances/FinancialCard';
import { FileDown, Filter } from 'lucide-react-native';
import { router } from 'expo-router';
import LoanTracker from '@/components/finances/LoanTracker';

export default function FinancesScreen() {
  const { trips } = useTrips();
  const [timeRange, setTimeRange] = useState('month'); // 'week', 'month', 'year'
  
  const summary = calculateTripSummary(trips);
  
  return (
    <SafeAreaView style={styles.container} edges={['right', 'left']}>
      <ScrollView style={styles.scrollView} contentContainerStyle={styles.contentContainer}>
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Financial Overview</Text>
          <View style={styles.headerActions}>
            <TouchableOpacity style={styles.filterButton}>
              <Filter size={18} color={THEME.colors.primary} />
              <Text style={styles.filterText}>Filter</Text>
            </TouchableOpacity>
            <TouchableOpacity 
              style={styles.exportButton}
              onPress={() => router.push('/export/finances')}
            >
              <FileDown size={18} color={THEME.colors.white} />
            </TouchableOpacity>
          </View>
        </View>
        
        <View style={styles.timeRangeSelector}>
          <TouchableOpacity 
            style={[styles.timeRangeButton, timeRange === 'week' && styles.activeTimeRange]}
            onPress={() => setTimeRange('week')}
          >
            <Text style={[styles.timeRangeText, timeRange === 'week' && styles.activeTimeRangeText]}>Week</Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={[styles.timeRangeButton, timeRange === 'month' && styles.activeTimeRange]}
            onPress={() => setTimeRange('month')}
          >
            <Text style={[styles.timeRangeText, timeRange === 'month' && styles.activeTimeRangeText]}>Month</Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={[styles.timeRangeButton, timeRange === 'year' && styles.activeTimeRange]}
            onPress={() => setTimeRange('year')}
          >
            <Text style={[styles.timeRangeText, timeRange === 'year' && styles.activeTimeRangeText]}>Year</Text>
          </TouchableOpacity>
        </View>
        
        <View style={styles.summaryContainer}>
          <FinancialCard
            title="Total Revenue"
            amount={summary.totalRevenue}
            growth={"+5.2%"}
            positive={true}
            icon="trending-up"
          />
          <FinancialCard
            title="Total Expenses"
            amount={summary.totalExpenses}
            growth={"-2.8%"}
            positive={false}
            icon="trending-down"
          />
          <FinancialCard
            title="Net Profit"
            amount={summary.profit}
            growth={"+8.4%"}
            positive={true}
            icon="dollar-sign"
          />
        </View>
        
        <View style={styles.chartSection}>
          <Text style={styles.sectionTitle}>Profit/Loss Trend</Text>
          <View style={styles.chartContainer}>
            <ProfitLossChart timeRange={timeRange} />
          </View>
        </View>
        
        <View style={styles.chartSection}>
          <Text style={styles.sectionTitle}>Expense Breakdown</Text>
          <View style={styles.chartContainer}>
            <ExpensePieChart />
          </View>
        </View>
        
        <View style={styles.chartSection}>
          <Text style={styles.sectionTitle}>Loan Tracker</Text>
          <LoanTracker />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: THEME.colors.background,
  },
  scrollView: {
    flex: 1,
  },
  contentContainer: {
    padding: 16,
    paddingBottom: 32,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  headerTitle: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 20,
    color: THEME.colors.text,
  },
  headerActions: {
    flexDirection: 'row',
  },
  filterButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(30, 136, 229, 0.1)',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    marginRight: 8,
  },
  filterText: {
    fontFamily: 'Poppins-Medium',
    color: THEME.colors.primary,
    marginLeft: 4,
  },
  exportButton: {
    backgroundColor: THEME.colors.secondary,
    padding: 8,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
  },
  timeRangeSelector: {
    flexDirection: 'row',
    backgroundColor: THEME.colors.backgroundLight,
    borderRadius: 12,
    marginBottom: 16,
    padding: 4,
  },
  timeRangeButton: {
    flex: 1,
    paddingVertical: 8,
    alignItems: 'center',
    borderRadius: 8,
  },
  activeTimeRange: {
    backgroundColor: THEME.colors.white,
    ...THEME.shadowProps,
  },
  timeRangeText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 14,
    color: THEME.colors.textLight,
  },
  activeTimeRangeText: {
    color: THEME.colors.primary,
  },
  summaryContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 24,
  },
  chartSection: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 18,
    color: THEME.colors.text,
    marginBottom: 12,
  },
  chartContainer: {
    backgroundColor: THEME.colors.white,
    borderRadius: 12,
    padding: 16,
    ...THEME.shadowProps,
  },
});