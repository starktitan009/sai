import React, { useState } from 'react';
import { View, Text, StyleSheet, Switch, TouchableOpacity, ScrollView, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { THEME } from '@/constants/Theme';
import { Moon, Sun, Database, Bell, Lock, CircleHelp as HelpCircle, Info, LogOut } from 'lucide-react-native';
import SettingItem from '@/components/settings/SettingItem';

export default function SettingsScreen() {
  const [darkMode, setDarkMode] = useState(false);
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [backupEnabled, setBackupEnabled] = useState(false);
  
  const toggleDarkMode = () => setDarkMode(prev => !prev);
  const toggleNotifications = () => setNotificationsEnabled(prev => !prev);
  const toggleBackup = () => setBackupEnabled(prev => !prev);
  
  const clearAppData = () => {
    // Clear app data logic would go here
    alert('Application data has been cleared.');
  };
  
  return (
    <SafeAreaView style={styles.container} edges={['right', 'left']}>
      <ScrollView style={styles.scrollView} contentContainerStyle={styles.contentContainer}>
        <Text style={styles.title}>Settings</Text>
        <Text style={styles.subtitle}>Configure your application preferences</Text>
        
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Appearance</Text>
          <View style={styles.settingCard}>
            <SettingItem
              icon={darkMode ? <Moon size={24} color={THEME.colors.primary} /> : <Sun size={24} color={THEME.colors.primary} />}
              title="Dark Mode"
              description="Use dark theme throughout the app"
              control={
                <Switch
                  value={darkMode}
                  onValueChange={toggleDarkMode}
                  trackColor={{ false: '#D1D5DB', true: THEME.colors.primaryLight }}
                  thumbColor={darkMode ? THEME.colors.primary : '#f4f3f4'}
                  ios_backgroundColor="#D1D5DB"
                />
              }
            />
          </View>
        </View>
        
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>App Preferences</Text>
          <View style={styles.settingCard}>
            <SettingItem
              icon={<Bell size={24} color={THEME.colors.primary} />}
              title="Notifications"
              description="Receive reminders for maintenance and trips"
              control={
                <Switch
                  value={notificationsEnabled}
                  onValueChange={toggleNotifications}
                  trackColor={{ false: '#D1D5DB', true: THEME.colors.primaryLight }}
                  thumbColor={notificationsEnabled ? THEME.colors.primary : '#f4f3f4'}
                  ios_backgroundColor="#D1D5DB"
                />
              }
            />
            
            <View style={styles.divider} />
            
            <SettingItem
              icon={<Database size={24} color={THEME.colors.primary} />}
              title="Auto Backup"
              description="Automatically backup your data locally"
              control={
                <Switch
                  value={backupEnabled}
                  onValueChange={toggleBackup}
                  trackColor={{ false: '#D1D5DB', true: THEME.colors.primaryLight }}
                  thumbColor={backupEnabled ? THEME.colors.primary : '#f4f3f4'}
                  ios_backgroundColor="#D1D5DB"
                />
              }
            />
          </View>
        </View>
        
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Security & Privacy</Text>
          <View style={styles.settingCard}>
            <SettingItem
              icon={<Lock size={24} color={THEME.colors.primary} />}
              title="App Lock"
              description="Secure your data with a passcode"
              isButton
            />
            
            <View style={styles.divider} />
            
            <SettingItem
              icon={<Database size={24} color={THEME.colors.danger} />}
              title="Clear App Data"
              description="Reset all data to default"
              isButton
              onPress={clearAppData}
              danger
            />
          </View>
        </View>
        
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>About</Text>
          <View style={styles.settingCard}>
            <SettingItem
              icon={<HelpCircle size={24} color={THEME.colors.primary} />}
              title="Help & Support"
              description="Get assistance with the app"
              isButton
            />
            
            <View style={styles.divider} />
            
            <SettingItem
              icon={<Info size={24} color={THEME.colors.primary} />}
              title="About App"
              description="Version 1.0.0"
              isButton
            />
          </View>
        </View>
        
        <TouchableOpacity style={styles.logoutButton}>
          <LogOut size={20} color={THEME.colors.white} />
          <Text style={styles.logoutText}>Logout</Text>
        </TouchableOpacity>
        
        <View style={styles.footer}>
          <Text style={styles.footerText}>Truck Transport Manager v1.0</Text>
          <Text style={styles.copyright}>© 2025 All Rights Reserved</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: THEME.colors.background,
  },
  scrollView: {
    flex: 1,
  },
  contentContainer: {
    padding: 16,
    paddingBottom: 32,
  },
  title: {
    fontFamily: 'Poppins-Bold',
    fontSize: 24,
    color: THEME.colors.text,
    marginBottom: 4,
  },
  subtitle: {
    fontFamily: 'Poppins-Regular',
    fontSize: 16,
    color: THEME.colors.textLight,
    marginBottom: 24,
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 18,
    color: THEME.colors.text,
    marginBottom: 12,
  },
  settingCard: {
    backgroundColor: THEME.colors.white,
    borderRadius: 12,
    ...THEME.shadowProps,
  },
  divider: {
    height: 1,
    backgroundColor: THEME.colors.backgroundLight,
    marginHorizontal: 16,
  },
  logoutButton: {
    backgroundColor: THEME.colors.danger,
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginVertical: 16,
  },
  logoutText: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 16,
    color: THEME.colors.white,
    marginLeft: 8,
  },
  footer: {
    marginTop: 16,
    alignItems: 'center',
  },
  footerText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 14,
    color: THEME.colors.textLight,
  },
  copyright: {
    fontFamily: 'Poppins-Regular',
    fontSize: 12,
    color: THEME.colors.textMuted,
    marginTop: 4,
  }
});