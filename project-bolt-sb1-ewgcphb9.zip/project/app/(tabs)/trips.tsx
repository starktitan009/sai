import React, { useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, TextInput } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { THEME } from '@/constants/Theme';
import TripCard from '@/components/trips/TripCard';
import { useTrips } from '@/hooks/useTrips';
import { Trip } from '@/types/Trip';
import { router } from 'expo-router';
import { Search, FileDown } from 'lucide-react-native';
import AddTripButton from '@/components/trips/AddTripButton';
import EmptyState from '@/components/ui/EmptyState';

export default function TripsScreen() {
  const { trips } = useTrips();
  const [searchQuery, setSearchQuery] = useState('');
  
  const filteredTrips = trips.filter(trip => 
    trip.from.toLowerCase().includes(searchQuery.toLowerCase()) ||
    trip.to.toLowerCase().includes(searchQuery.toLowerCase()) ||
    trip.truckNumber.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  const renderItem = ({ item }: { item: Trip }) => (
    <TripCard 
      trip={item} 
      onPress={() => router.push(`/trip/details/${item.id}`)} 
    />
  );
  
  const navigateToExport = () => {
    router.push('/export/trips');
  };
  
  return (
    <SafeAreaView style={styles.container} edges={['right', 'left']}>
      <View style={styles.header}>
        <View style={styles.searchContainer}>
          <Search size={20} color={THEME.colors.textLight} style={styles.searchIcon} />
          <TextInput
            style={styles.searchInput}
            placeholder="Search trips..."
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholderTextColor={THEME.colors.textLight}
          />
        </View>
        <TouchableOpacity style={styles.exportButton} onPress={navigateToExport}>
          <FileDown size={20} color={THEME.colors.white} />
        </TouchableOpacity>
      </View>
      
      {trips.length > 0 ? (
        <FlatList
          data={filteredTrips}
          renderItem={renderItem}
          keyExtractor={item => item.id}
          contentContainerStyle={styles.listContainer}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={() => (
            <View style={styles.emptySearch}>
              <Text style={styles.emptySearchText}>No trips found matching "{searchQuery}"</Text>
            </View>
          )}
        />
      ) : (
        <EmptyState
          title="No Trips Yet"
          message="Add your first trip to start tracking your transport details"
          icon="truck"
        />
      )}
      
      <AddTripButton />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: THEME.colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    backgroundColor: THEME.colors.white,
    ...THEME.shadowProps,
  },
  searchContainer: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: THEME.colors.backgroundLight,
    borderRadius: 8,
    paddingHorizontal: 12,
    height: 46,
  },
  searchIcon: {
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    height: 46,
    color: THEME.colors.text,
    fontFamily: 'Poppins-Regular',
  },
  exportButton: {
    backgroundColor: THEME.colors.secondary,
    width: 46,
    height: 46,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 12,
  },
  listContainer: {
    padding: 16,
    paddingBottom: 100,
  },
  emptySearch: {
    padding: 24,
    alignItems: 'center',
  },
  emptySearchText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 16,
    color: THEME.colors.textLight,
    textAlign: 'center',
  }
});