import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { THEME } from '@/constants/Theme';
import { useDocuments } from '@/hooks/useDocuments';
import { Document } from '@/types/Document';
import DocumentCard from '@/components/documents/DocumentCard';
import { Plus, FileText } from 'lucide-react-native';
import EmptyState from '@/components/ui/EmptyState';

export default function DocumentsScreen() {
  const { documents, addDocument } = useDocuments();
  const [activeTab, setActiveTab] = useState('truck'); // 'truck', 'receipts', 'other'
  
  const filteredDocuments = documents.filter(doc => doc.type === activeTab);
  
  const renderItem = ({ item }: { item: Document }) => (
    <DocumentCard document={item} />
  );
  
  const handleAddDocument = () => {
    // In a real app, this would open a document picker
    // For demo purposes, we'll add a mock document
    const newDoc: Document = {
      id: (documents.length + 1).toString(),
      title: `Document ${documents.length + 1}`,
      type: activeTab,
      fileName: `document_${Date.now()}.pdf`,
      fileSize: '2.4 MB',
      uploadDate: new Date().toISOString(),
      expiryDate: activeTab === 'truck' ? new Date(2025, 5, 15).toISOString() : null,
      thumbnailUrl: null,
      notes: 'Sample document added for demonstration'
    };
    
    addDocument(newDoc);
  };
  
  return (
    <SafeAreaView style={styles.container} edges={['right', 'left']}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Documents</Text>
        <TouchableOpacity style={styles.addButton} onPress={handleAddDocument}>
          <Plus size={20} color={THEME.colors.white} />
        </TouchableOpacity>
      </View>
      
      <View style={styles.tabsContainer}>
        <TouchableOpacity 
          style={[styles.tab, activeTab === 'truck' && styles.activeTab]}
          onPress={() => setActiveTab('truck')}
        >
          <Text style={[styles.tabText, activeTab === 'truck' && styles.activeTabText]}>
            Truck Documents
          </Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={[styles.tab, activeTab === 'receipts' && styles.activeTab]}
          onPress={() => setActiveTab('receipts')}
        >
          <Text style={[styles.tabText, activeTab === 'receipts' && styles.activeTabText]}>
            Receipts
          </Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={[styles.tab, activeTab === 'other' && styles.activeTab]}
          onPress={() => setActiveTab('other')}
        >
          <Text style={[styles.tabText, activeTab === 'other' && styles.activeTabText]}>
            Other
          </Text>
        </TouchableOpacity>
      </View>
      
      {filteredDocuments.length > 0 ? (
        <FlatList
          data={filteredDocuments}
          renderItem={renderItem}
          keyExtractor={item => item.id}
          contentContainerStyle={styles.listContainer}
          showsVerticalScrollIndicator={false}
        />
      ) : (
        <EmptyState
          title="No Documents Yet"
          message={`Add your first ${activeTab} document to keep everything organized`}
          icon="file-text"
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: THEME.colors.background,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    backgroundColor: THEME.colors.white,
    ...THEME.shadowProps,
  },
  headerTitle: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 20,
    color: THEME.colors.text,
  },
  addButton: {
    backgroundColor: THEME.colors.primary,
    width: 46,
    height: 46,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
  },
  tabsContainer: {
    flexDirection: 'row',
    backgroundColor: THEME.colors.backgroundLight,
    padding: 8,
    marginHorizontal: 16,
    marginTop: 16,
    borderRadius: 12,
  },
  tab: {
    flex: 1,
    paddingVertical: 10,
    alignItems: 'center',
    borderRadius: 8,
  },
  activeTab: {
    backgroundColor: THEME.colors.white,
    ...THEME.shadowProps,
  },
  tabText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 14,
    color: THEME.colors.textLight,
  },
  activeTabText: {
    color: THEME.colors.primary,
  },
  listContainer: {
    padding: 16,
    paddingBottom: 32,
  },
});