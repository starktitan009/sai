import React, { useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { THEME } from '@/constants/Theme';
import DashboardSummary from '@/components/home/DashboardSummary';
import RecentTripsCard from '@/components/home/RecentTripsCard';
import UpcomingMaintenanceCard from '@/components/home/UpcomingMaintenanceCard';
import { loadDemoData } from '@/utils/demoData';
import ProfitLossChart from '@/components/charts/ProfitLossChart';
import AddTripButton from '@/components/trips/AddTripButton';

export default function HomeScreen() {
  useEffect(() => {
    // Load demo data only in development
    loadDemoData();
  }, []);
  
  return (
    <SafeAreaView style={styles.container} edges={['right', 'left']}>
      <ScrollView style={styles.scrollView} contentContainerStyle={styles.contentContainer}>
        <View style={styles.header}>
          <Text style={styles.welcomeText}>Welcome back</Text>
          <Text style={styles.headerSubtitle}>Your transport overview for today</Text>
        </View>
        
        <DashboardSummary />
        
        <View style={styles.sectionContainer}>
          <Text style={styles.sectionTitle}>Profit/Loss Overview</Text>
          <View style={styles.chartContainer}>
            <ProfitLossChart />
          </View>
        </View>
        
        <View style={styles.sectionContainer}>
          <Text style={styles.sectionTitle}>Recent Trips</Text>
          <RecentTripsCard />
        </View>
        
        <View style={styles.sectionContainer}>
          <Text style={styles.sectionTitle}>Upcoming Maintenance</Text>
          <UpcomingMaintenanceCard />
        </View>
        
        <View style={styles.footer}>
          <Text style={styles.footerText}>Truck Transport Manager v1.0</Text>
          <Text style={styles.footerSubtext}>Data is stored locally on your device</Text>
        </View>
      </ScrollView>
      
      <AddTripButton />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: THEME.colors.background,
  },
  scrollView: {
    flex: 1,
  },
  contentContainer: {
    padding: 16,
    paddingBottom: 100,
  },
  header: {
    marginBottom: 20,
  },
  welcomeText: {
    fontFamily: 'Poppins-Bold',
    fontSize: 24,
    color: THEME.colors.text,
  },
  headerSubtitle: {
    fontFamily: 'Poppins-Regular',
    fontSize: 16,
    color: THEME.colors.textLight,
  },
  sectionContainer: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 18,
    color: THEME.colors.text,
    marginBottom: 12,
  },
  chartContainer: {
    backgroundColor: THEME.colors.white,
    borderRadius: 12,
    padding: 16,
    ...THEME.shadowProps,
    height: 250,
  },
  footer: {
    marginTop: 20,
    alignItems: 'center',
  },
  footerText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 14,
    color: THEME.colors.textLight,
  },
  footerSubtext: {
    fontFamily: 'Poppins-Regular',
    fontSize: 12,
    color: THEME.colors.textMuted,
    marginTop: 4,
  }
});