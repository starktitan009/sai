import Colors from './Colors';

export const THEME = {
  colors: {
    primary: Colors.primary,
    primaryLight: Colors.primaryLight,
    primaryDark: Colors.primaryDark,
    
    secondary: Colors.secondary,
    secondaryLight: Colors.secondaryLight,
    secondaryDark: Colors.secondaryDark,
    
    success: Colors.success,
    warning: Colors.warning,
    danger: Colors.danger,
    
    background: Colors.background,
    backgroundLight: Colors.backgroundLight,
    
    white: Colors.white,
    black: Colors.black,
    
    text: Colors.text,
    textLight: Colors.textLight,
    textMuted: Colors.textMuted,
    
    border: Colors.border,
  },
  
  // Consistent shadow styles for cards
  shadowProps: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 2,
  },
  
  // Spacing scale based on 8px
  spacing: {
    xs: 4,
    sm: 8,
    md: 16,
    lg: 24,
    xl: 32,
    xxl: 48,
  },
  
  // Border radius scale
  borderRadius: {
    xs: 4,
    sm: 8,
    md: 12,
    lg: 16,
    xl: 24,
    round: 999,
  },
};