export default {
  primary: '#1E88E5',    // Primary blue
  primaryLight: '#64B5F6',
  primaryDark: '#1565C0',
  
  secondary: '#F57C00',  // Orange accent
  secondaryLight: '#FFB74D',
  secondaryDark: '#E65100',
  
  success: '#4CAF50',    // Green
  warning: '#FFC107',    // Amber
  danger: '#F44336',     // Red
  
  background: '#F5F7FA',
  backgroundLight: '#F0F2F5',
  
  white: '#FFFFFF',
  black: '#000000',
  
  text: '#202124',
  textLight: '#5F6368',
  textMuted: '#9AA0A6',
  
  border: '#DFE1E5',
  gray: '#9E9E9E',
  lightGray: '#E0E0E0',
};