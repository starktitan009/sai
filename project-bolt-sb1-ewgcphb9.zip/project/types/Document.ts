export interface Document {
  id: string;
  title: string;
  type: 'truck' | 'receipts' | 'other';
  fileName: string;
  fileSize: string;
  uploadDate: string;
  expiryDate: string | null;
  thumbnailUrl: string | null;
  notes?: string;
}