export interface Trip {
  id: string;
  from: string;
  to: string;
  startDate: string;
  endDate: string;
  truckNumber: string;
  revenue: number;
  driverName: string;
  coDriverName?: string;
  expenses: TripExpense[];
  documents: TripDocument[];
  status: 'ongoing' | 'completed' | 'cancelled';
  createdAt: string;
}

export interface TripExpense {
  type: string;
  amount: number;
  notes?: string;
}

export interface TripDocument {
  id: string;
  title: string;
  fileType: string;
  fileSize: string;
  uploadDate: string;
  url?: string;
  thumbnailUrl?: string;
}