export interface Driver {
  id: string;
  name: string;
  phone: string;
  licenseNumber: string;
  licenseExpiry: string;
  address: string;
  photo: string | null;
  joinDate: string;
  status: 'active' | 'inactive' | 'on-leave';
  trips: string[]; // Trip IDs
}