export interface MaintenanceItem {
  id: string;
  title: string;
  description: string;
  truckId: string;
  cost: number;
  scheduledDate: string;
  completedDate?: string;
  status: 'scheduled' | 'completed' | 'cancelled';
  documents: string[]; // Document IDs
}