// Format a date as MM/DD/YYYY
export function format(date: Date): string {
  const day = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const year = date.getFullYear();
  
  return `${month}/${day}/${year}`;
}

// Get a date X days from now
export function getDateDaysFromNow(days: number): Date {
  const date = new Date();
  date.setDate(date.getDate() + days);
  return date;
}

// Check if a date is in the past
export function isPastDate(date: Date): boolean {
  const now = new Date();
  return date < now;
}

// Check if a date is in the future
export function isFutureDate(date: Date): boolean {
  const now = new Date();
  return date > now;
}

// Check if a date is today
export function isToday(date: Date): boolean {
  const now = new Date();
  return (
    date.getDate() === now.getDate() &&
    date.getMonth() === now.getMonth() &&
    date.getFullYear() === now.getFullYear()
  );
}

// Format date as relative time (e.g., Today, Yesterday, 3 days ago)
export function formatRelative(date: Date): string {
  const now = new Date();
  const diffTime = Math.abs(now.getTime() - date.getTime());
  const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
  
  if (isToday(date)) {
    return 'Today';
  }
  
  if (diffDays === 1) {
    return date > now ? 'Tomorrow' : 'Yesterday';
  }
  
  if (diffDays < 7) {
    return date > now ? `In ${diffDays} days` : `${diffDays} days ago`;
  }
  
  return format(date);
}