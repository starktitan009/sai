import AsyncStorage from '@react-native-async-storage/async-storage';
import { Trip } from '@/types/Trip';
import { Driver } from '@/types/Driver';
import { Document } from '@/types/Document';
import { MaintenanceItem } from '@/types/Maintenance';

// Keys for AsyncStorage
const TRIPS_STORAGE_KEY = '@truck_manager:trips';
const DRIVERS_STORAGE_KEY = '@truck_manager:drivers';
const DOCUMENTS_STORAGE_KEY = '@truck_manager:documents';
const MAINTENANCE_STORAGE_KEY = '@truck_manager:maintenance';

// Trip Storage
export const saveTrips = async (trips: Trip[]) => {
  try {
    await AsyncStorage.setItem(TRIPS_STORAGE_KEY, JSON.stringify(trips));
    return true;
  } catch (error) {
    console.error('Error saving trips:', error);
    return false;
  }
};

export const loadTrips = async (): Promise<Trip[] | null> => {
  try {
    const tripsData = await AsyncStorage.getItem(TRIPS_STORAGE_KEY);
    return tripsData ? JSON.parse(tripsData) : [];
  } catch (error) {
    console.error('Error loading trips:', error);
    return null;
  }
};

// Driver Storage
export const saveDrivers = async (drivers: Driver[]) => {
  try {
    await AsyncStorage.setItem(DRIVERS_STORAGE_KEY, JSON.stringify(drivers));
    return true;
  } catch (error) {
    console.error('Error saving drivers:', error);
    return false;
  }
};

export const loadDrivers = async (): Promise<Driver[] | null> => {
  try {
    const driversData = await AsyncStorage.getItem(DRIVERS_STORAGE_KEY);
    return driversData ? JSON.parse(driversData) : [];
  } catch (error) {
    console.error('Error loading drivers:', error);
    return null;
  }
};

// Document Storage
export const saveDocuments = async (documents: Document[]) => {
  try {
    await AsyncStorage.setItem(DOCUMENTS_STORAGE_KEY, JSON.stringify(documents));
    return true;
  } catch (error) {
    console.error('Error saving documents:', error);
    return false;
  }
};

export const loadDocuments = async (): Promise<Document[] | null> => {
  try {
    const documentsData = await AsyncStorage.getItem(DOCUMENTS_STORAGE_KEY);
    return documentsData ? JSON.parse(documentsData) : [];
  } catch (error) {
    console.error('Error loading documents:', error);
    return null;
  }
};

// Maintenance Storage
export const saveMaintenanceItems = async (items: MaintenanceItem[]) => {
  try {
    await AsyncStorage.setItem(MAINTENANCE_STORAGE_KEY, JSON.stringify(items));
    return true;
  } catch (error) {
    console.error('Error saving maintenance items:', error);
    return false;
  }
};

export const loadMaintenanceItems = async (): Promise<MaintenanceItem[] | null> => {
  try {
    const itemsData = await AsyncStorage.getItem(MAINTENANCE_STORAGE_KEY);
    return itemsData ? JSON.parse(itemsData) : [];
  } catch (error) {
    console.error('Error loading maintenance items:', error);
    return null;
  }
};

// Clear All Data
export const clearAllData = async () => {
  try {
    await AsyncStorage.multiRemove([
      TRIPS_STORAGE_KEY,
      DRIVERS_STORAGE_KEY,
      DOCUMENTS_STORAGE_KEY,
      MAINTENANCE_STORAGE_KEY
    ]);
    return true;
  } catch (error) {
    console.error('Error clearing data:', error);
    return false;
  }
};