import { Trip } from '@/types/Trip';

// Calculate total profit for a trip
export function calculateTripProfit(trip: Trip): number {
  const totalExpenses = trip.expenses.reduce((sum, expense) => sum + expense.amount, 0);
  return trip.revenue - totalExpenses;
}

// Calculate summary data for trips
export function calculateTripSummary(trips: Trip[]) {
  // Filter trips from current month
  const now = new Date();
  const currentMonth = now.getMonth();
  const currentYear = now.getFullYear();
  
  const monthlyTrips = trips.filter(trip => {
    const tripDate = new Date(trip.startDate);
    return tripDate.getMonth() === currentMonth && tripDate.getFullYear() === currentYear;
  });
  
  let totalRevenue = 0;
  let totalExpenses = 0;
  
  monthlyTrips.forEach(trip => {
    totalRevenue += trip.revenue;
    
    const tripExpenses = trip.expenses.reduce((sum, expense) => sum + expense.amount, 0);
    totalExpenses += tripExpenses;
  });
  
  const profit = totalRevenue - totalExpenses;
  
  return {
    totalTrips: trips.length,
    monthlyTrips: monthlyTrips.length,
    totalRevenue,
    totalExpenses,
    profit
  };
}

// Calculate expense breakdown by category
export function calculateExpenseBreakdown(trips: Trip[]) {
  const expensesByCategory: Record<string, number> = {
    fuel: 0,
    driver: 0,
    coDriver: 0,
    toll: 0,
    maintenance: 0,
    other: 0
  };
  
  trips.forEach(trip => {
    trip.expenses.forEach(expense => {
      if (expensesByCategory[expense.type] !== undefined) {
        expensesByCategory[expense.type] += expense.amount;
      } else {
        expensesByCategory.other += expense.amount;
      }
    });
  });
  
  const totalExpenses = Object.values(expensesByCategory).reduce((sum, amount) => sum + amount, 0);
  
  // Convert to percentages
  const percentages: Record<string, number> = {};
  if (totalExpenses > 0) {
    Object.keys(expensesByCategory).forEach(category => {
      percentages[category] = (expensesByCategory[category] / totalExpenses) * 100;
    });
  }
  
  return {
    amounts: expensesByCategory,
    percentages,
    total: totalExpenses
  };
}