import { Trip } from '@/types/Trip';
import { Driver } from '@/types/Driver';
import { Document } from '@/types/Document';
import { MaintenanceItem } from '@/types/Maintenance';
import { saveTrips, saveDrivers, saveDocuments, saveMaintenanceItems, loadTrips } from './storage';

// Create demo data for testing
export const loadDemoData = async () => {
  // Check if we already have data
  const existingTrips = await loadTrips();
  if (existingTrips && existingTrips.length > 0) {
    return; // Skip loading demo data if we already have trips
  }
  
  // Demo trips - one example of each status
  const trips: Trip[] = [
    {
      id: '1',
      from: 'New York',
      to: 'Chicago',
      startDate: new Date(2025, 2, 12).toISOString(),
      endDate: new Date(2025, 2, 14).toISOString(),
      truckNumber: 'T-1001',
      revenue: 3500,
      driverName: 'John Smith',
      coDriverName: 'Mike Johnson',
      expenses: [
        { type: 'fuel', amount: 850, notes: 'Diesel' },
        { type: 'driver', amount: 600, notes: 'Driver payment' },
        { type: 'coDriver', amount: 450, notes: 'Co-driver payment' },
        { type: 'toll', amount: 120, notes: 'Highway tolls' },
        { type: 'other', amount: 75, notes: 'Miscellaneous' }
      ],
      documents: [
        {
          id: '101',
          title: 'Delivery Receipt',
          fileType: 'PDF',
          fileSize: '1.2 MB',
          uploadDate: new Date(2025, 2, 14).toISOString(),
          url: 'https://example.com/receipt1.pdf'
        }
      ],
      status: 'completed',
      createdAt: new Date(2025, 2, 10).toISOString()
    }
  ];
  
  // Demo drivers - keep only the active ones
  const drivers: Driver[] = [
    {
      id: '1',
      name: 'John Smith',
      phone: '(555) 123-4567',
      licenseNumber: 'DL78945612',
      licenseExpiry: new Date(2026, 5, 15).toISOString(),
      address: '123 Main St, Chicago, IL 60007',
      photo: null,
      joinDate: new Date(2023, 1, 10).toISOString(),
      status: 'active',
      trips: ['1']
    },
    {
      id: '2',
      name: 'Mike Johnson',
      phone: '(555) 789-0123',
      licenseNumber: 'DL78901234',
      licenseExpiry: new Date(2025, 9, 30).toISOString(),
      address: '321 Elm St, New York, NY 10001',
      photo: null,
      joinDate: new Date(2022, 11, 15).toISOString(),
      status: 'active',
      trips: ['1']
    }
  ];
  
  // Demo documents - one of each type
  const documents: Document[] = [
    {
      id: '1',
      title: 'Truck Registration T-1001',
      type: 'truck',
      fileName: 'truck_1001_registration.pdf',
      fileSize: '2.4 MB',
      uploadDate: new Date(2023, 5, 10).toISOString(),
      expiryDate: new Date(2025, 5, 10).toISOString(),
      thumbnailUrl: null,
      notes: 'Annual registration for T-1001'
    },
    {
      id: '2',
      title: 'Fuel Receipt Chicago',
      type: 'receipts',
      fileName: 'fuel_receipt_chicago.jpg',
      fileSize: '1.1 MB',
      uploadDate: new Date(2025, 2, 13).toISOString(),
      expiryDate: null,
      thumbnailUrl: null,
      notes: 'Diesel refill during NY-Chicago trip'
    },
    {
      id: '3',
      title: 'Driver Contract',
      type: 'other',
      fileName: 'driver_contract.pdf',
      fileSize: '1.8 MB',
      uploadDate: new Date(2023, 7, 15).toISOString(),
      expiryDate: null,
      thumbnailUrl: null,
      notes: 'Employment contract for John Smith'
    }
  ];
  
  // Demo maintenance items - one upcoming maintenance
  const maintenanceItems: MaintenanceItem[] = [
    {
      id: '1',
      title: 'Oil Change T-1001',
      description: 'Regular oil change and filter replacement',
      truckId: 'T-1001',
      cost: 250,
      scheduledDate: new Date(2025, 4, 15).toISOString(),
      status: 'scheduled',
      documents: []
    }
  ];
  
  // Save demo data to storage
  await saveTrips(trips);
  await saveDrivers(drivers);
  await saveDocuments(documents);
  await saveMaintenanceItems(maintenanceItems);
};