import { useState, useEffect } from 'react';
import { Driver } from '@/types/Driver';
import { loadDrivers, saveDrivers } from '@/utils/storage';

export function useDrivers() {
  const [drivers, setDrivers] = useState<Driver[]>([]);
  
  useEffect(() => {
    // Load drivers from storage on initial mount
    loadDrivers().then(loadedDrivers => {
      if (loadedDrivers) {
        setDrivers(loadedDrivers);
      }
    });
  }, []);
  
  const addDriver = (driver: Driver) => {
    const updatedDrivers = [...drivers, driver];
    setDrivers(updatedDrivers);
    saveDrivers(updatedDrivers);
  };
  
  const updateDriver = (updatedDriver: Driver) => {
    const updatedDrivers = drivers.map(driver => 
      driver.id === updatedDriver.id ? updatedDriver : driver
    );
    setDrivers(updatedDrivers);
    saveDrivers(updatedDrivers);
  };
  
  const removeDriver = (driverId: string) => {
    const updatedDrivers = drivers.filter(driver => driver.id !== driverId);
    setDrivers(updatedDrivers);
    saveDrivers(updatedDrivers);
  };
  
  const getDriver = (driverId: string) => {
    return drivers.find(driver => driver.id === driverId);
  };
  
  return {
    drivers,
    addDriver,
    updateDriver,
    removeDriver,
    getDriver
  };
}