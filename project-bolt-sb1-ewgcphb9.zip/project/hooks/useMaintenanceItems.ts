import { useState, useEffect } from 'react';
import { MaintenanceItem } from '@/types/Maintenance';
import { loadMaintenanceItems, saveMaintenanceItems } from '@/utils/storage';

export function useMaintenanceItems() {
  const [maintenanceItems, setMaintenanceItems] = useState<MaintenanceItem[]>([]);
  
  useEffect(() => {
    // Load maintenance items from storage on initial mount
    loadMaintenanceItems().then(loadedItems => {
      if (loadedItems) {
        setMaintenanceItems(loadedItems);
      }
    });
  }, []);
  
  const addMaintenanceItem = (item: MaintenanceItem) => {
    const updatedItems = [...maintenanceItems, item];
    setMaintenanceItems(updatedItems);
    saveMaintenanceItems(updatedItems);
  };
  
  const updateMaintenanceItem = (updatedItem: MaintenanceItem) => {
    const updatedItems = maintenanceItems.map(item => 
      item.id === updatedItem.id ? updatedItem : item
    );
    setMaintenanceItems(updatedItems);
    saveMaintenanceItems(updatedItems);
  };
  
  const removeMaintenanceItem = (itemId: string) => {
    const updatedItems = maintenanceItems.filter(item => item.id !== itemId);
    setMaintenanceItems(updatedItems);
    saveMaintenanceItems(updatedItems);
  };
  
  const getMaintenanceItem = (itemId: string) => {
    return maintenanceItems.find(item => item.id === itemId);
  };
  
  return {
    maintenanceItems,
    addMaintenanceItem,
    updateMaintenanceItem,
    removeMaintenanceItem,
    getMaintenanceItem
  };
}