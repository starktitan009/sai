import { useState, useEffect } from 'react';
import { Trip } from '@/types/Trip';
import { loadTrips, saveTrips } from '@/utils/storage';

export function useTrips() {
  const [trips, setTrips] = useState<Trip[]>([]);
  
  useEffect(() => {
    // Load trips from storage on initial mount
    loadTrips().then(loadedTrips => {
      if (loadedTrips) {
        setTrips(loadedTrips);
      }
    });
  }, []);
  
  const addTrip = (trip: Trip) => {
    const updatedTrips = [...trips, trip];
    setTrips(updatedTrips);
    saveTrips(updatedTrips);
  };
  
  const updateTrip = (updatedTrip: Trip) => {
    const updatedTrips = trips.map(trip => 
      trip.id === updatedTrip.id ? updatedTrip : trip
    );
    setTrips(updatedTrips);
    saveTrips(updatedTrips);
  };
  
  const removeTrip = (tripId: string) => {
    const updatedTrips = trips.filter(trip => trip.id !== tripId);
    setTrips(updatedTrips);
    saveTrips(updatedTrips);
  };
  
  const getTrip = (tripId: string) => {
    return trips.find(trip => trip.id === tripId);
  };
  
  const updateTripStatus = (tripId: string, status: 'ongoing' | 'completed' | 'cancelled') => {
    const trip = getTrip(tripId);
    if (trip) {
      const updatedTrip = { ...trip, status };
      updateTrip(updatedTrip);
    }
  };
  
  return {
    trips,
    addTrip,
    updateTrip,
    removeTrip,
    getTrip,
    updateTripStatus
  };
}