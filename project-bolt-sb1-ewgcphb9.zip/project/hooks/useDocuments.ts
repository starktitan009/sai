import { useState, useEffect } from 'react';
import { Document } from '@/types/Document';
import { loadDocuments, saveDocuments } from '@/utils/storage';

export function useDocuments() {
  const [documents, setDocuments] = useState<Document[]>([]);
  
  useEffect(() => {
    // Load documents from storage on initial mount
    loadDocuments().then(loadedDocuments => {
      if (loadedDocuments) {
        setDocuments(loadedDocuments);
      }
    });
  }, []);
  
  const addDocument = (document: Document) => {
    const updatedDocuments = [...documents, document];
    setDocuments(updatedDocuments);
    saveDocuments(updatedDocuments);
  };
  
  const updateDocument = (updatedDocument: Document) => {
    const updatedDocuments = documents.map(document => 
      document.id === updatedDocument.id ? updatedDocument : document
    );
    setDocuments(updatedDocuments);
    saveDocuments(updatedDocuments);
  };
  
  const removeDocument = (documentId: string) => {
    const updatedDocuments = documents.filter(document => document.id !== documentId);
    setDocuments(updatedDocuments);
    saveDocuments(updatedDocuments);
  };
  
  const getDocument = (documentId: string) => {
    return documents.find(document => document.id === documentId);
  };
  
  return {
    documents,
    addDocument,
    updateDocument,
    removeDocument,
    getDocument
  };
}